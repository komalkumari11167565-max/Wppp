# RAJ X Mafia — Web Pairing Dashboard (v2)

This build asks for the WhatsApp phone number on the website dashboard. It does **not** ask for a phone number in the server terminal and contains no `readline` prompt.

## Project layout
- `package.json` — ES module project; keep `"type": "module"`.
- `server.js` — Express + Baileys API; `/api/pair` accepts the phone number from the dashboard.
- `public/index.html` — dashboard form for phone number and pairing code.
- `public/app.js` — sends the entered number to `/api/pair`.

## Render setup when the ZIP itself is stored in the GitHub repository
- Root Directory: leave blank
- Build Command: `unzip -o raj-x-mafia-web-pairing-v2.zip -d . && cd raj-x-mafia-render && npm install`
- Start Command: `cd raj-x-mafia-render && npm start`
- Environment variable: `ADMIN_PASSWORD` = choose a strong dashboard password

After deployment, open the Render service URL, enter `ADMIN_PASSWORD`, choose a bot, enter the WhatsApp number with country code (digits only), and click **Generate pairing code**. Do not enter the phone number in Render Shell.

If instead you extract the ZIP before uploading to GitHub and put the contents of `raj-x-mafia-render/` at the repository root, use `npm install` as Build Command and `npm start` as Start Command, with Root Directory blank.

Pair only an account you own or are authorized to manage. Keep the dashboard password, pairing code, and session files private. Render's free web services do not provide persistent disks, so the session may need to be paired again after a restart.
