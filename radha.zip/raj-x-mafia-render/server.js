import { createRequire } from 'module';
const require = createRequire(import.meta.url);

const NOISE = [
    'Closing open session','Closing session','SessionEntry','_chains',
    'registrationId','currentRatchet','ephemeralKeyPair','indexInfo',
    'prekey','chainKey','chainType','messageKeys','pendingPreKey',
    'rootKey','privKey','pubKey','remoteIdentityKey','lastRemoteEphemeralKey',
    'baseKeyType','Bad MAC','Session error','decryptWithSessions',
    'doDecryptWhisperMessage','libsignal','session_cipher','<Buffer','Buffer ',
];
const isNoise = (...a) => {
    const s = a.flat().map(x => String(x ?? '')).join(' ');
    return NOISE.some(p => s.includes(p));
};
const _ol = console.log.bind(console);
const _oe = console.error.bind(console);
const _ow = console.warn.bind(console);
const _so = process.stdout.write.bind(process.stdout);
const _se = process.stderr.write.bind(process.stderr);
console.log   = (...a) => { if (!isNoise(a)) _ol(...a); };
console.error = (...a) => { if (!isNoise(a)) _oe(...a); };
console.warn  = (...a) => { if (!isNoise(a)) _ow(...a); };
const fw = orig => (chunk, enc, cb) => {
    if (isNoise(chunk?.toString?.() ?? '')) {
        if (typeof enc === 'function') enc();
        else if (typeof cb === 'function') cb();
        return true;
    }
    return orig(chunk, enc, cb);
};
process.stdout.write = fw(_so);
process.stderr.write = fw(_se);

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    jidNormalizedUser,
    downloadContentFromMessage,
    Browsers,
} = require('@whiskeysockets/baileys');
const pino     = require('pino');
const fs       = require('fs');
const http     = require('http');
const https    = require('https');
const readline = require('readline');
const rl       = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask      = q => new Promise(r => rl.question(q, r));

const BOT_NAME    = 'RAJ X Mafia';
const MAX_BOTS    = 4;
const STATE_FILE  = './radhika-state.json';
const STICKER_DIR = './saved-stickers';
const IMAGE_DIR   = './saved-images';
const SESSION_DIR = i => `./sessions/bot${i}`;
const MAX_STICKER_BYTES = 2 * 1024 * 1024;
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const ALLOWED_IMAGE_MIME_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const MAX_STICKERS_PER_GROUP = 30;
const MAX_IMAGES_PER_GROUP = 30;
const DEFAULT_MEDIA_COOLDOWN_SECONDS = 5;
const MIN_MEDIA_COOLDOWN_SECONDS = 5;
const MAX_MEDIA_COOLDOWN_SECONDS = 3600;
const DEFAULT_MEDIA_SEND_DELAY_MS = 1500;
const MIN_MEDIA_SEND_DELAY_MS = 1000;
const MAX_MEDIA_SEND_DELAY_MS = 3600000;

const DEFAULT_SPAM_DELAY    = 2500;
const DEFAULT_NC_DELAY      = 1000;
const DEFAULT_DC_DELAY      = 5000;
const DEFAULT_PFP_DELAY     = 8000;
const DEFAULT_PINSPAM_DELAY = 3000;
const DEFAULT_PIN_COUNT     = 5;
const DEFAULT_TAGALL_DELAY  = 5000;
const DEFAULT_SOLO_DELAY    = 3000;
const DEFAULT_S2_DELAY      = 3000;

const CUTE_EMOJIS = [
    '🌸','💕','✨','🦋','🍓','🌷','🌺','💖','🌼','🍑',
    '🎀','🌈','💫','🌻','🍒','💗','🌙','⭐','🎶','🍭',
    '🫧','🩷','🌝','🦄','🌟','🍬','🎠','🩰','🌹','💐',
];

const sockets      = new Map();
const owners       = new Set();
const subAdmins    = new Set();
const spamTasks    = new Map();
const rspamTasks   = new Map();
const pollTasks    = new Map();
const ncTasks      = new Map();
const dcTasks      = new Map();
const pfpTasks     = new Map();
const pinspamTasks = new Map();
const tagallTasks  = new Map();
const soloTasks      = new Map();
const s2Tasks        = new Map();
const antilinkGroups = new Set();

// group jid -> Set of phone numbers to auto-delete
const autoDeleteTargets = new Map();
// group jid -> Set of saved sticker IDs; sticker files live in STICKER_DIR
const savedStickers = new Map();
// group jid -> Set of saved image IDs; image files live in IMAGE_DIR
const savedImages = new Map();
const savedImageMimeTypes = new Map();
// group jid -> configured sticker/image cooldown in seconds
const mediaCooldowns = new Map();
// group jid + media type -> delay between repeated sends in milliseconds
const mediaSendDelays = new Map();
const mediaSendLastAt = new Map();
const mediaSendTasks = new Map();
// group jid -> array of custom poll options (set via /oppoll)
const pollOptions = new Map();
// phone number -> auto reply message (DM only)
const autoReplyTargets = new Map();
// group jid -> Set of phone numbers to random-reply whenever they message
const targetedUsers = new Map();
// group jid -> protected group subject
const gcNameProtections = new Map();
const gcNameProtectionInFlight = new Set();

let   autoReactEmoji = null;
const randomReactChats = new Set(); // jids where /reaction is ON
const spamDelays     = new Map();
const ncDelays       = new Map();
const dcDelays       = new Map();
const pfpDelays      = new Map();
const pinspamDelays  = new Map();
const pinCounts      = new Map();
const tagallDelays   = new Map();
const soloDelays     = new Map();
const s2Delays       = new Map();
let taskResumeTimer   = null;

// ─── State persistence ───────────────────────────────────────────────────────

function saveState() {
    try {
        const adObj = {};
        autoDeleteTargets.forEach((set, jid) => { adObj[jid] = [...set]; });
        const poObj = {};
        pollOptions.forEach((opts, jid) => { poObj[jid] = opts; });
        fs.writeFileSync(STATE_FILE, JSON.stringify({
            owners:            [...owners],
            subAdmins:         [...subAdmins],
            autoReactEmoji,
            randomReactChats: [...randomReactChats],
            autoDeleteTargets: adObj,
            savedStickers: Object.fromEntries([...savedStickers].map(([j, ids]) => [j, [...ids]])),
            savedImages: Object.fromEntries([...savedImages].map(([j, ids]) => [j, [...ids]])),
            savedImageMimeTypes: Object.fromEntries([...savedImageMimeTypes].map(([j, mimeTypes]) => [j, Object.fromEntries(mimeTypes)])),
            mediaCooldowns: Object.fromEntries(mediaCooldowns),
            mediaSendDelays: Object.fromEntries(mediaSendDelays),
            gcNameProtections: Object.fromEntries(gcNameProtections),
            pollOptions:       poObj,
            spamDelays:        Object.fromEntries(spamDelays),
            ncDelays:          Object.fromEntries(ncDelays),
            dcDelays:          Object.fromEntries(dcDelays),
            pfpDelays:         Object.fromEntries(pfpDelays),
            pinspamDelays:     Object.fromEntries(pinspamDelays),
            pinCounts:         Object.fromEntries(pinCounts),
            soloDelays:        Object.fromEntries(soloDelays),
            s2Delays:          Object.fromEntries(s2Delays),
            antilinkGroups:    [...antilinkGroups],
            autoReplyTargets:  Object.fromEntries(autoReplyTargets),
            targetedUsers:     Object.fromEntries([...targetedUsers].map(([j,s])=>[j,[...s]])),
            activeTasks: {
                spam:    Object.fromEntries([...spamTasks    ].map(([k,v])=>[k,{message:v.message,delay:v.delay,botCount:v.botCount}])),
                rspam:   Object.fromEntries([...rspamTasks   ].map(([k,v])=>[k,{message:v.message,delay:v.delay,botCount:v.botCount,quotedKey:v.quotedKey}])),
                poll:    Object.fromEntries([...pollTasks    ].map(([k,v])=>[k,{topic:v.topic,delay:v.delay,botCount:v.botCount}])),
                nc:      Object.fromEntries([...ncTasks      ].map(([k,v])=>[k,{baseName:v.baseName,delay:v.delay,botCount:v.botCount}])),
                dc:      Object.fromEntries([...dcTasks      ].map(([k,v])=>[k,{baseDesc:v.baseDesc,delay:v.delay,botCount:v.botCount}])),
                pfp:     Object.fromEntries([...pfpTasks     ].map(([k,v])=>[k,{pfpFile:v.pfpFile,delay:v.delay,botCount:v.botCount}])),
                pinspam: Object.fromEntries([...pinspamTasks ].map(([k,v])=>[k,{message:v.message,delay:v.delay,botCount:v.botCount,count:v.count}])),
                tagall:  Object.fromEntries([...tagallTasks  ].map(([k,v])=>[k,{message:v.message,delay:v.delay,botCount:v.botCount}])),
                solo:    Object.fromEntries([...soloTasks    ].map(([k,v])=>[k,{delay:v.delay,botCount:v.botCount}])),
                s2:      Object.fromEntries([...s2Tasks      ].map(([k,v])=>[k,{delay:v.delay,botCount:v.botCount}])),
            },
        }, null, 2));
    } catch {}
}

function loadState() {
    try { return fs.existsSync(STATE_FILE) ? JSON.parse(fs.readFileSync(STATE_FILE,'utf8')) : null; }
    catch { return null; }
}

function resumeState(cfg) {
    if (!cfg) return;
    (cfg.owners||[]).forEach(j=>owners.add(j));
    (cfg.subAdmins||[]).forEach(j=>subAdmins.add(j));
    if (cfg.autoReactEmoji) autoReactEmoji = cfg.autoReactEmoji;
    (cfg.randomReactChats||[]).forEach(j=>randomReactChats.add(j));
    Object.entries(cfg.autoDeleteTargets||{}).forEach(([j,arr])=>{
        autoDeleteTargets.set(j, new Set(Array.isArray(arr) ? arr : [arr]));
    });
    Object.entries(cfg.savedStickers||{}).forEach(([j,ids])=>{
        const validIds = (Array.isArray(ids) ? ids : [])
            .map(String)
            .filter(id => /^[1-9]\d{0,2}$/.test(id));
        if (validIds.length) savedStickers.set(j, new Set(validIds));
    });
    Object.entries(cfg.savedImages||{}).forEach(([j,ids])=>{
        const validIds = (Array.isArray(ids) ? ids : [])
            .map(String)
            .filter(id => /^[1-9]\d{0,2}$/.test(id));
        if (validIds.length) savedImages.set(j, new Set(validIds));
    });
    Object.entries(cfg.savedImageMimeTypes||{}).forEach(([j,mimeTypes])=>{
        const validMimeTypes = Object.entries(mimeTypes || {})
            .filter(([id,mimetype]) =>
                /^[1-9]\d{0,2}$/.test(id) && ALLOWED_IMAGE_MIME_TYPES.has(mimetype));
        if (validMimeTypes.length) savedImageMimeTypes.set(j, new Map(validMimeTypes));
    });
    Object.entries(cfg.mediaCooldowns||{}).forEach(([j,seconds])=>{
        const value = Number(seconds);
        if (Number.isInteger(value) &&
            value >= MIN_MEDIA_COOLDOWN_SECONDS &&
            value <= MAX_MEDIA_COOLDOWN_SECONDS) mediaCooldowns.set(j, value);
    });
    Object.entries(cfg.mediaSendDelays||{}).forEach(([key,delayMs])=>{
        const value = Number(delayMs);
        if (Number.isInteger(value) &&
            value >= MIN_MEDIA_SEND_DELAY_MS &&
            value <= MAX_MEDIA_SEND_DELAY_MS) mediaSendDelays.set(key, value);
    });
    Object.entries(cfg.gcNameProtections||{}).forEach(([j,subject])=>{
        if (typeof subject === 'string' && subject.trim()) gcNameProtections.set(j, subject);
    });
    Object.entries(cfg.pollOptions||{}).forEach(([j,opts])=>pollOptions.set(j, opts));
    Object.entries(cfg.spamDelays   ||{}).forEach(([k,v])=>spamDelays.set(k,v));
    Object.entries(cfg.ncDelays     ||{}).forEach(([k,v])=>ncDelays.set(k,v));
    Object.entries(cfg.dcDelays     ||{}).forEach(([k,v])=>dcDelays.set(k,v));
    Object.entries(cfg.pfpDelays    ||{}).forEach(([k,v])=>pfpDelays.set(k,v));
    Object.entries(cfg.pinspamDelays||{}).forEach(([k,v])=>pinspamDelays.set(k,v));
    Object.entries(cfg.pinCounts    ||{}).forEach(([k,v])=>pinCounts.set(k,v));
    Object.entries(cfg.soloDelays   ||{}).forEach(([k,v])=>soloDelays.set(k,v));
    Object.entries(cfg.s2Delays     ||{}).forEach(([k,v])=>s2Delays.set(k,v));
    (cfg.antilinkGroups||[]).forEach(j=>antilinkGroups.add(j));
    Object.entries(cfg.autoReplyTargets||{}).forEach(([num,msg])=>{
        const normalized = normalizePhoneNumber(num);
        if (normalized && typeof msg === 'string') autoReplyTargets.set(normalized, msg);
    });
    Object.entries(cfg.targetedUsers||{}).forEach(([j,arr])=>{
        targetedUsers.set(j, new Set(Array.isArray(arr)?arr:[arr]));
    });
    Object.entries(cfg.activeTasks?.spam    ||{}).forEach(([j,c])=>startSpam(j,c.botCount,c.message,c.delay,true));
    Object.entries(cfg.activeTasks?.rspam   ||{}).forEach(([j,c])=>c.quotedKey && startRspam(j,c.botCount,c.message,c.delay,c.quotedKey,true));
    Object.entries(cfg.activeTasks?.poll    ||{}).forEach(([j,c])=>startPollSpam(j,c.botCount,c.topic,c.delay,true));
    Object.entries(cfg.activeTasks?.nc      ||{}).forEach(([j,c])=>startNc(j,c.botCount,c.baseName,c.delay,true));
    Object.entries(cfg.activeTasks?.dc      ||{}).forEach(([j,c])=>startDc(j,c.botCount,c.baseDesc,c.delay,true));
    Object.entries(cfg.activeTasks?.pfp     ||{}).forEach(([j,c])=>c.pfpFile && startPfpChange(j,c.botCount,c.pfpFile,c.delay,true));
    Object.entries(cfg.activeTasks?.pinspam ||{}).forEach(([j,c])=>startPinSpam(j,c.botCount,c.message,c.delay,c.count||DEFAULT_PIN_COUNT,true));
    Object.entries(cfg.activeTasks?.tagall  ||{}).forEach(([j,c])=>startTagAll(j,c.botCount,c.message,c.delay,true));
    Object.entries(cfg.activeTasks?.solo    ||{}).forEach(([j,c])=>startSolo(j,c.botCount,c.delay,true));
    Object.entries(cfg.activeTasks?.s2      ||{}).forEach(([j,c])=>startS2(j,c.botCount,c.delay,true));
}

function scheduleTaskResume() {
    clearTimeout(taskResumeTimer);
    taskResumeTimer = setTimeout(() => {
        const cfg = loadState();
        if (cfg?.activeTasks) {
            _ol(`[TASKS] Resuming saved tasks with ${sockets.size} connected bot(s)`);
            resumeState(cfg);
        }
    }, 1200);
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const randEmoji = () => CUTE_EMOJIS[Math.floor(Math.random()*CUTE_EMOJIS.length)];
const jidToNum  = j  => (j||'').split('@')[0].split(':')[0];
function findBotGroupParticipant(sock, participants) {
    const botIds = new Set([
        sock.user?.id,
        sock.user?.lid,
        sock.authState?.creds?.me?.id,
        sock.authState?.creds?.me?.lid,
    ].filter(Boolean).map(id => jidNormalizedUser(String(id))));
    const botNumbers = new Set([...botIds].map(jidToNum).filter(Boolean));
    return participants?.find(participant =>
        [participant.id, participant.lid, participant.phoneNumber]
            .filter(Boolean)
            .some(id => {
                const normalizedId = jidNormalizedUser(String(id));
                const participantNumber = jidToNum(normalizedId);
                return botIds.has(normalizedId) ||
                    (participantNumber && botNumbers.has(participantNumber));
            })
    );
}
const getDelay  = (map,jid,def) => map.has(jid) ? map.get(jid) : def;
const msToSec   = ms => (ms/1000).toFixed(1) + 's';
const sleep     = ms => new Promise(r=>setTimeout(r,ms));
const getSavedStickerPath = (groupJid, id) =>
    `${STICKER_DIR}/${Buffer.from(groupJid).toString('hex')}_${id}.webp`;
const getSavedImagePath = (groupJid, id) =>
    `${IMAGE_DIR}/${Buffer.from(groupJid).toString('hex')}_${id}.img`;
function normalizePhoneNumber(value) {
    let digits = String(value || '').replace(/\D/g, '');
    if (digits.startsWith('00')) digits = digits.slice(2);
    return digits;
}

function getActiveSockets(n) {
    return [...sockets.values()].slice(0, Math.min(n, sockets.size));
}

function isOwner(senderJid) {
    const n = jidToNum(senderJid);
    return [...owners].some(o => jidToNum(o) === n);
}

function isAuthorized(senderJid) {
    const n = jidToNum(senderJid);
    for (const o of owners)    if (jidToNum(o) === n) return true;
    for (const a of subAdmins) if (jidToNum(a) === n) return true;
    return false;
}

async function reply(jid, text, quoted) {
    const s = getActiveSockets(1)[0];
    if (!s) return;
    try { await s.sendMessage(jid, { text }, quoted ? { quoted } : {}); }
    catch {}
}

async function enforceGcNameProtection(sock, groupJid, protectedSubject) {
    if (gcNameProtectionInFlight.has(groupJid)) return;
    gcNameProtectionInFlight.add(groupJid);
    try {
        const metadata = await sock.groupMetadata(groupJid);
        if (gcNameProtections.get(groupJid) !== protectedSubject ||
            metadata.subject === protectedSubject) return;

        const botParticipant = findBotGroupParticipant(sock, metadata.participants);
        if (!botParticipant || !['admin', 'superadmin'].includes(botParticipant.admin)) {
            console.warn(`[GC PROTECT] Bot 1 is not an admin in ${groupJid}; cannot restore the saved name.`);
            return;
        }

        await sock.groupUpdateSubject(groupJid, protectedSubject);
        console.log(`[GC PROTECT] Restored group name for ${groupJid}.`);
    } catch (e) {
        console.error(`[GC PROTECT] Could not restore ${groupJid}: ${e.message}`);
    } finally {
        gcNameProtectionInFlight.delete(groupJid);
    }
}

// ─── Task engine (async loop — no setInterval stalling) ──────────────────────

function makeTask(fn, onErr) {
    let alive = true;
    const stop = () => { alive = false; };
    const loop = async (d) => {
        while (alive) {
            try { await fn(); } catch(e) { if (onErr) onErr(e); }
            if (!alive) break;
            await sleep(d);
        }
    };
    return { stop, loop, isAlive: ()=>alive };
}

function stopTask(map, jid) {
    const t = map.get(jid);
    if (t) {
        t.runners.forEach(r => r.stop());
        map.delete(jid);
        saveState();
        return true;
    }
    return false;
}

function clampBots(n) { return Math.min(Math.max(parseInt(n)||1,1),MAX_BOTS); }

// ─── Spam ─────────────────────────────────────────────────────────────────────

function startSpam(jid, botCount, message, d, silent=false) {
    stopTask(spamTasks, jid);
    const sockList = getActiveSockets(botCount);
    const runners  = sockList.map(s => {
        const t = makeTask(
            () => s.sendMessage(jid, { text: message }),
            e => _ol('[SPAM] send error; loop kept alive:', e.message)
        );
        t.loop(d);
        return t;
    });
    spamTasks.set(jid, { runners, botCount, message, delay: d });
    saveState();
    return silent ? null : `╔══〔 🔥 *SPAM ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per message\n┃ Msg: ${message}\n╚══════════════════╝`;
}

// ─── Reply Spam (swipe spam) ──────────────────────────────────────────────────

function startRspam(jid, botCount, message, d, quotedKey, silent=false) {
    stopTask(rspamTasks, jid);
    const sockList = getActiveSockets(botCount);
    const fakeQuoted = { key: quotedKey, message: { conversation: message } };
    const runners  = sockList.map(s => {
        const t = makeTask(() => s.sendMessage(jid, { text: message }, { quoted: fakeQuoted }));
        t.loop(d);
        return t;
    });
    rspamTasks.set(jid, { runners, botCount, message, delay: d, quotedKey });
    saveState();
    return silent ? null : `╔══〔 💬 *REPLY SPAM ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per reply\n┃ Msg: ${message}\n╚══════════════════╝`;
}

// ─── Poll Spam ────────────────────────────────────────────────────────────────

function startPollSpam(jid, botCount, topic, d, silent=false) {
    stopTask(pollTasks, jid);
    const sockList = getActiveSockets(botCount);
    let   counter  = 0;
    const runners  = sockList.map(s => {
        const t = makeTask(async () => {
            const num    = ++counter;
            const custom = pollOptions.get(jid);
            const values = custom?.length
                ? custom.slice(0, 8)
                : Array.from({length:8}, (_,i)=>`${topic} ${num + i}`);
            await s.sendMessage(jid, {
                poll: { name: topic, values, selectableCount: 1 }
            });
        });
        t.loop(d);
        return t;
    });
    pollTasks.set(jid, { runners, botCount, topic, delay: d });
    saveState();
    const customOpts = pollOptions.get(jid);
    const optsPreview = customOpts ? customOpts.slice(0,3).join(', ')+'...' : 'Auto-numbered';
    return silent ? null : `╔══〔 📊 *POLL SPAM ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per poll\n┃ Topic: ${topic}\n┃ Options: ${optsPreview}\n╚══════════════════╝`;
}

// ─── NC — async loop fix (no stalling) ───────────────────────────────────────

function startNc(jid, botCount, baseName, d, silent=false) {
    stopTask(ncTasks, jid);
    const sockList = getActiveSockets(botCount);
    if (!sockList.length) return silent ? null : '❌ No bot is connected!';
    const runners = sockList.map((s, idx) => {
        const t = makeTask(() => {
            for (let i = 0; i < 3; i++) {
                try {
                    Promise.resolve(
                        s.groupUpdateSubject(jid, `${baseName} ${randEmoji()}`)
                    ).catch(e => _ol('[NC] request error; loop kept alive:', e.message));
                } catch (e) {
                    _ol('[NC] sync error; loop kept alive:', e.message);
                }
            }
        });
        setTimeout(() => t.loop(d), idx * 50);
        return t;
    });
    ncTasks.set(jid, { runners, botCount, baseName, delay: d });
    saveState();
    return silent ? null : `╔══〔 ✏️ *NC ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per cycle\n┃ Name: ${baseName}\n╚══════════════════╝`;
}

// ─── DC — async loop fix (no stalling) ───────────────────────────────────────

function startDc(jid, botCount, baseDesc, d, silent=false) {
    stopTask(dcTasks, jid);
    const sockList = getActiveSockets(botCount);
    const runners  = sockList.map((s, idx) => {
        const t = makeTask(() => {
            for (let i = 0; i < 3; i++) {
                try {
                    Promise.resolve(
                        s.groupUpdateDescription(jid, `${baseDesc} ${randEmoji()}`)
                    ).catch(e => _ol('[DC] request error; loop kept alive:', e.message));
                } catch (e) {
                    _ol('[DC] sync error; loop kept alive:', e.message);
                }
            }
        });
        setTimeout(() => t.loop(d), idx * 50);
        return t;
    });
    dcTasks.set(jid, { runners, botCount, baseDesc, delay: d });
    saveState();
    return silent ? null : `╔══〔 📝 *DC ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per change\n┃ Desc: ${baseDesc}\n╚══════════════════╝`;
}

// ─── PFP Changer ─────────────────────────────────────────────────────────────

function startPfpChange(jid, botCount, pfpFile, d, silent=false) {
    stopTask(pfpTasks, jid);
    if (!fs.existsSync(pfpFile)) return silent ? null : '❌ PFP file not found! Send an image first.';
    const sockList = getActiveSockets(botCount);
    const runners  = sockList.map((s, idx) => {
        const t = makeTask(async () => {
            const buf = fs.readFileSync(pfpFile);
            await s.updateProfilePicture(jid, buf);
            _ol('[PFP] ✅ updateProfilePicture success on bot', idx+1);
        }, (e) => _ol('[PFP] ❌ updateProfilePicture error:', e.message));
        setTimeout(() => t.loop(d), idx * Math.floor(d / Math.max(sockList.length,1)));
        return t;
    });
    pfpTasks.set(jid, { runners, botCount, pfpFile, delay: d });
    saveState();
    return silent ? null : `╔══〔 🖼️ *PFP CHANGE ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per change\n┃ File: ${pfpFile}\n╚══════════════════╝`;
}

// ─── Pin Spam ─────────────────────────────────────────────────────────────────

function startPinSpam(jid, botCount, message, d, count, silent=false) {
    stopTask(pinspamTasks, jid);
    const sockList = getActiveSockets(botCount);
    const runners  = sockList.map(s => {
        const t = makeTask(async () => {
            let lastSent = null;
            for (let i = 0; i < count; i++) {
                try {
                    const sent = await s.sendMessage(jid, { text: message });
                    if (sent?.key) lastSent = sent;
                } catch {}
                await sleep(d);
            }
            if (lastSent?.key) {
                let pinned = false;
                try {
                    await s.sendMessage(jid, { pin: lastSent.key, type: 1 });
                    pinned = true;
                } catch {}
                if (!pinned) {
                    try {
                        await s.relayMessage(jid, {
                            pinInChatMessage: {
                                key:               lastSent.key,
                                type:              1,
                                senderTimestampMs: Date.now(),
                            }
                        }, {});
                    } catch {}
                }
            }
        });
        t.loop(0);
        return t;
    });
    pinspamTasks.set(jid, { runners, botCount, message, delay: d, count });
    saveState();
    return silent ? null : `╔══〔 📌 *PIN SPAM ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Msgs per cycle: *${count}*\n┃ Delay: *${msToSec(d)}* per msg\n┃ Msg: ${message}\n╚══════════════════╝`;
}

// ─── Tag All ─────────────────────────────────────────────────────────────────

function startTagAll(jid, botCount, message, d, silent=false) {
    stopTask(tagallTasks, jid);
    const sockList = getActiveSockets(botCount);
    const runners  = sockList.map((s, idx) => {
        const t = makeTask(async () => {
            const meta         = await s.groupMetadata(jid);
            const participants = meta.participants.map(p => p.id);
            const tagText      = participants.map(p => `@${jidToNum(p)}`).join(' ');
            const fullText     = message ? `${message}\n${tagText}` : tagText;
            await s.sendMessage(jid, { text: fullText, mentions: participants });
        });
        setTimeout(() => t.loop(d), idx * 500);
        return t;
    });
    tagallTasks.set(jid, { runners, botCount, message, delay: d });
    saveState();
    return silent ? null : `╔══〔 👥 *TAG ALL ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per tag\n┃ Msg: ${message||'(tags only)'}\n╚══════════════════╝`;
}

// ─── S2 — toggle Send Messages (announcement ↔ not_announcement) in loop ──────

function startS2(jid, botCount, d, silent=false) {
    stopTask(s2Tasks, jid);
    const sockList = getActiveSockets(botCount);
    if (!sockList.length) return silent ? null : '❌ No bot is connected!';
    const runners = sockList.map((s, idx) => {
        let toggle = true;
        const t = makeTask(async () => {
            await s.groupSettingUpdate(jid, toggle ? 'announcement' : 'not_announcement');
            toggle = !toggle;
        });
        setTimeout(() => t.loop(d), idx * 150);
        return t;
    });
    s2Tasks.set(jid, { runners, botCount, delay: d });
    saveState();
    return silent ? null : `╔══〔 💬 *S2 LOOP ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per toggle\n┃ Send Msgs: only admins ↔ everyone\n╚══════════════════╝`;
}

// ─── Solo — toggle locked/unlocked in loop ────────────────────────────────────

function startSolo(jid, botCount, d, silent=false) {
    stopTask(soloTasks, jid);
    const sockList = getActiveSockets(botCount);
    const runners  = sockList.map((s, idx) => {
        let toggle = true;
        const t = makeTask(async () => {
            await s.groupSettingUpdate(jid, toggle ? 'locked' : 'unlocked');
            toggle = !toggle;
        });
        setTimeout(() => t.loop(d), idx * 150);
        return t;
    });
    soloTasks.set(jid, { runners, botCount, delay: d });
    saveState();
    return silent ? null : `╔══〔 🔒 *SOLO LOOP ON* 〕══╗\n┃ Bots: *${sockList.length}/${MAX_BOTS}*\n┃ Speed: *${msToSec(d)}* per toggle\n┃ locked ↔ unlocked loop running\n╚══════════════════╝`;
}

// ─── Spotify Search ───────────────────────────────────────────────────────────

const SPOTIFY_CLIENT_ID     = process.env.SPOTIFY_CLIENT_ID     || '45dbfe82aa5142a49edb7422a79e3ff6';
const SPOTIFY_CLIENT_SECRET = process.env.SPOTIFY_CLIENT_SECRET || '14dba99c74f64d638c72c5603029a135';
let   spotifyToken       = null;
let   spotifyTokenExpiry = 0;

async function getSpotifyToken() {
    if (spotifyToken && Date.now() < spotifyTokenExpiry) return spotifyToken;
    const creds = Buffer.from(`${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`).toString('base64');
    const body  = 'grant_type=client_credentials';
    const data  = await new Promise((resolve, reject) => {
        const req = https.request({
            hostname: 'accounts.spotify.com',
            path:     '/api/token',
            method:   'POST',
            headers: {
                'Authorization':  `Basic ${creds}`,
                'Content-Type':   'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(body),
            },
        }, res => {
            let d = '';
            res.on('data', c => d += c);
            res.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
        });
        req.on('error', reject);
        req.write(body);
        req.end();
    });
    if (!data.access_token) throw new Error('Spotify token failed: ' + JSON.stringify(data));
    spotifyToken       = data.access_token;
    spotifyTokenExpiry = Date.now() + (data.expires_in - 60) * 1000;
    return spotifyToken;
}

async function searchSpotify(query) {
    const token = await getSpotifyToken();
    const url   = `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=1`;
    const data  = await new Promise((resolve, reject) => {
        const req = https.get(url, {
            headers: { 'Authorization': `Bearer ${token}`, 'User-Agent': 'Mozilla/5.0' },
        }, res => {
            let d = '';
            res.on('data', c => d += c);
            res.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
        });
        req.on('error', reject);
        req.setTimeout(10000, () => { req.destroy(); reject(new Error('Spotify timeout')); });
    });
    const track = data?.tracks?.items?.[0];
    if (!track) return null;
    return {
        title:       track.name,
        artist:      track.artists.map(a => a.name).join(', '),
        album:       track.album?.name || '',
        releaseYear: track.album?.release_date?.slice(0, 4) || '',
        imageUrl:    track.album?.images?.[0]?.url || null,
        previewUrl:  track.preview_url || null,
    };
}

// ─── JioSaavn Search ─────────────────────────────────────────────────────────

function fetchJson(url) {
    return new Promise((resolve, reject) => {
        const req = https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, res => {
            let data = '';
            res.on('data', c => data += c);
            res.on('end', () => { try { resolve(JSON.parse(data)); } catch(e) { reject(e); } });
        });
        req.on('error', reject);
        req.setTimeout(10000, () => { req.destroy(); reject(new Error('timeout')); });
    });
}

// ─── HTTP buffer download with redirect support ───────────────────────────────

function downloadBuffer(url) {
    return new Promise((resolve, reject) => {
        const doGet = (u, redirects = 0) => {
            if (redirects > 5) return reject(new Error('Too many redirects'));
            const mod = u.startsWith('https') ? https : http;
            const req = mod.get(u, { headers: { 'User-Agent': 'Mozilla/5.0' } }, res => {
                if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                    return doGet(res.headers.location, redirects + 1);
                }
                if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
                const chunks = [];
                res.on('data', c => chunks.push(c));
                res.on('end', () => resolve(Buffer.concat(chunks)));
            });
            req.on('error', reject);
            req.setTimeout(30000, () => { req.destroy(); reject(new Error('Download timeout')); });
        };
        doGet(url);
    });
}

// ─── JioSaavn — song search + download ───────────────────────────────────────

async function searchJioSaavn(query) {
    const url = `https://jiosavan-api2.vercel.app/api/search/songs?query=${encodeURIComponent(query)}&limit=5`;
    const data = await fetchJson(url);
    const songs = data?.data?.results;
    if (!songs || songs.length === 0) return null;

    let chosen = null, audioUrl = null, bitrate = '320kbps';
    for (const song of songs) {
        const urls = song.downloadUrl;
        if (!urls || !urls.length) continue;
        const sorted = [...urls].sort((a, b) => parseInt(b.quality) - parseInt(a.quality));
        const best = sorted.find(u => u.url && u.url.startsWith('http'));
        if (best) {
            chosen = song;
            audioUrl = best.url;
            bitrate = best.quality ? `${best.quality}kbps` : bitrate;
            break;
        }
    }
    if (!chosen || !audioUrl) return null;

    const title    = chosen.name || query;
    const artist   = chosen.artists?.primary?.map(a => a.name).join(', ') || 'Unknown';
    const album    = chosen.album?.name || '';
    const durSec   = chosen.duration || 0;
    const duration = durSec ? `${Math.floor(durSec/60)}:${String(durSec%60).padStart(2,'0')}` : '';

    return {
        title,
        artist,
        album,
        duration,
        audioUrl,
        imageUrl: chosen.image || chosen.imageUrl || chosen.album?.image || null,
        year: chosen.year || chosen.releaseDate?.slice?.(0, 4) || '',
        plays: chosen.playCount || chosen.playCountText || chosen.play_count || '',
        bitrate,
    };
}

// ─── Audius — free music search + stream ─────────────────────────────────────

async function searchAudius(query) {
    const hostsData = await fetchJson('https://api.audius.co');
    const host = (hostsData?.data || [])[0];
    if (!host) throw new Error('No Audius host available');

    const res = await fetchJson(
        `${host}/v1/tracks/search?query=${encodeURIComponent(query)}&limit=5&app_name=RAJXMafia`
    );
    const track = res?.data?.[0];
    if (!track) return null;

    return {
        title:     track.title,
        artist:    track.user?.name || 'Unknown',
        duration:  track.duration
            ? `${Math.floor(track.duration/60)}:${String(track.duration%60).padStart(2,'0')}`
            : '',
        streamUrl: `${host}/v1/tracks/${track.id}/stream?app_name=RAJXMafia`,
    };
}

async function sendSongCover(sock, jid, imageUrl, caption, quoted) {
    if (!imageUrl) return false;
    try {
        const image = await downloadBuffer(imageUrl);
        await sock.sendMessage(jid, { image, caption }, { quoted });
        return true;
    } catch (e) {
        _ol('[COVER ERROR]', e.message);
        return false;
    }
}

// ─── Random target-reply pool ─────────────────────────────────────────────────

const RANDOM_REACT_EMOJIS = [
    '❤️','😂','😍','🔥','💀','⚔️','😎','🤣','👀','💯',
    '🫡','🥶','😈','🤯','💪','👑','🫶','😏','🤩','⚡',
    '🙈','😴','🥹','💅','🤡','👻','🎯','🫠','😤','🦁',
];

const TARGET_REPLIES = [
    'Kesi ho? 😊',
    'Kya krte ho? 🤔',
    'Khana khaye? 🍽️',
    'Good night! 🌙',
    'Good evening! 🌇',
    'Good afternoon! ☀️',
    'A gaye aap! 😄',
    'Kesi ho aap? 💫',
    'Sab theek? 🙂',
    'Kahan the itne din? 👀',
    'Yaad aa gaye 😌',
    'Kuch chahiye? 😏',
];

// ─── Menu ─────────────────────────────────────────────────────────────────────

function buildMenu() {
    return `
╔══════════════════════════════════╗
║        ☾ 𝐋 𝐎 𝐑 𝐃 〆 𝐗 ☽        ║
║       「 𝐃𝐀𝐑𝐊 𝐂𝐎𝐍𝐓𝐑𝐎𝐋 」       ║
╠══════════════════════════════════╣
║  ✦ SYSTEM  : 𝐀𝐂𝐓𝐈𝐕𝐄           ║
║  ✦ BOTS    : ${sockets.size}/${MAX_BOTS} 𝐎𝐍𝐋𝐈𝐍𝐄        ║
║  ✦ STATUS  : 𝐔𝐍𝐋𝐄𝐀𝐒𝐇𝐄𝐃        ║
╚══════════════════════════════════╝

        「 𝐃𝐀𝐑𝐊 𝐀𝐑𝐒𝐄𝐍𝐀𝐋 」

 ⚔️  /spam1 • /spam2 • /spam3 • /domain expansion
 ◈  /spam off • /spam delay • /spam info

 🩸  /rspam1 • /rspam2 • /rspam3 • /rspam4
 ◈  /rspam off • /rspam delay • /rspam info

 ☠️  /pollspam1 • /pollspam2 • /pollspam3 • /pollspam4
 ◈  /pollspam off • /pollspam delay • /pollspam info
 👑  /oppoll • /oppoll list • /oppoll off

        「 𝐃𝐎𝐌𝐀𝐈𝐍 𝐂𝐎𝐍𝐓𝐑𝐎𝐋 」

 👁️  /Shikai <name> • /Shikai2 <name>
 ◈  /nc off • /nc delay • /nc info

 🖤  /dc1 • /dc2 • /dc3 • /dc4
 ◈  /dc off • /dc delay • /dc info

 🪶  /pfp1 • /pfp2 • /pfp3 • /pfp4
 ◈  /pfp off • /pfp delay • /pfp info

 ⚜️  /pinspam1 • /pinspam2 • /pinspam3 • /pinspam4
 ◈  /pinspam off • /pinspam delay • /pinspam count • /pinspam info

        「 𝐒𝐇𝐀𝐃𝐎𝐖 𝐌𝐎𝐃𝐄𝐒 」

 🌑  /solo1 • /solo2 • /solo3 • /solo4
 ◈  /solo on • /solo off • /solo delay • /solo info

 👾  /s21 • /s22 • /s23 • /s24
 ◈  /s2 on • /s2 off • /s2 delay • /s2 info

 🎯  /bankai @user
 ◈  /bankai off @user • /bankai off all • /bankai list

        「 𝐃𝐄𝐅𝐄𝐍𝐒𝐄 𝐒𝐘𝐒𝐓𝐄𝐌 」

 🛡️  /antilink on • /antilink off • /antilink info
 🗑️  /auto delete <num> • /auto delete remove <num>
 🛑  /auto delete off • /auto info

        「 𝐀𝐔𝐓𝐎 𝐑𝐄𝐏𝐋𝐘 」

 🤖  /ar <num> <msg> • /ar off <num>
 ☠️  /ar off all • /ar list

        「 𝐌𝐔𝐒𝐈𝐂 𝐃𝐎𝐌𝐀𝐈𝐍 」

 🎵  /song <naam>
 🎶  /sg <naam>
 🎼  /geet <naam>

        「 𝐒𝐇𝐀𝐃𝐎𝐖 𝐀𝐑𝐌𝐘 」

 👥  /tagall1 • /tagall2 • /tagall3 • /tagall4
 ◈  /tagall off • /tagall delay • /tagall info

        「 𝐎𝐕𝐄𝐑𝐋𝐎𝐑더라고요 𝐂𝐎𝐑𝐄 」

 👑  /react • /stopreact
 🎲  /reaction • /reaction off
 🛡️  /gcpronc <name> • /gcpronc off
 🧸  /sticker save <id> • /sticker <id> • /sticker off
 🖼️  /image save <id> • /image <id> • /image off
 ⏱️  /sticker delay <ms> • /image delay <ms>
 ◈  /sticker cooldown <sec> (also sets image cooldown)
 💬  /gc list • /gc <n> <msg>
 ⚡  /addsubadmin • /removesubadmin • /listsubadmin
 🚫  /remove • 📡 /status • ☠️ /stopall • 📖 /menu

╭──────────────────────────────────╮
│        𓆩 𝐋𝐎𝐑𝐃 〆 𝐗 𓆪          │
│           「 𝐎𝐕𝐄𝐑𝐋𝐎𝐑𝐃 」         │
╰──────────────────────────────────╯`.trim();
}

// ─── Command handler ─────────────────────────────────────────────────────────

async function handleCommand(m, body, fromJid, senderJid, isGroup) {
    const raw = body.trim().split(/\s+/);
    let parts = raw;

    const shortMatch = raw[0].match(/^(\/(nc|dc|spam|rspam|pollspam|pfp|pinspam|tagall|solo|s2))([1-4])$/i);
    if (shortMatch) parts = [shortMatch[1], shortMatch[3], ...raw.slice(1)];

    const first = raw[0].toLowerCase();
    if (first === '/domain' && raw[1]?.toLowerCase() === 'expansion') {
        parts = ['/spam', '4', ...raw.slice(2)];
    } else if (first === '/sg') {
        parts = ['/gana', ...raw.slice(1)];
    } else if (first === '/bankai') {
        parts = ['/target', ...raw.slice(1)];
    } else if (first === '/shikai') {
        parts = ['/nc', '1', ...raw.slice(1)];
    } else if (first === '/shikai2') {
        parts = ['/nc', '2', ...raw.slice(1)];
    }

    const cmd = parts[0].toLowerCase();

    if (cmd === '/menu') { await reply(fromJid, buildMenu(), m); return; }

    if (cmd === '/status') {
        const adSet  = autoDeleteTargets.get(fromJid);
        const adInfo = adSet?.size ? `ON — ${[...adSet].join(', ')}` : 'OFF';
        const pinT   = pinspamTasks.get(fromJid);
        const lines = [
            `┏━━〔 ⚔️ *RAJ X BOT STATUS* 〕━━┓`,
            `┃ 🤖 Bots Online: *${sockets.size}/${MAX_BOTS}*`,
            `┃ 📨 Spam: *${spamTasks.has(fromJid) ? `ON — ${spamTasks.get(fromJid).botCount} bots` : 'OFF'}*`,
            `┃ 💬 Reply Spam: *${rspamTasks.has(fromJid) ? `ON — ${rspamTasks.get(fromJid).botCount} bots` : 'OFF'}*`,
            `┃ 📊 Poll Spam: *${pollTasks.has(fromJid) ? `ON — ${pollTasks.get(fromJid).botCount} bots` : 'OFF'}*`,
            `┃ ✏️ NC: *${ncTasks.has(fromJid) ? `ON — ${ncTasks.get(fromJid).botCount} bots` : 'OFF'}*`,
            `┃ 📝 DC: *${dcTasks.has(fromJid) ? `ON — ${dcTasks.get(fromJid).botCount} bots` : 'OFF'}*`,
            `┃ 🖼️ PFP: *${pfpTasks.has(fromJid) ? `ON — ${pfpTasks.get(fromJid).botCount} bots` : 'OFF'}*`,
            `┃ 📌 Pin Spam: *${pinT ? `ON — ${pinT.count} msgs→pin` : 'OFF'}*`,
            `┃ 👥 Tag All: *${tagallTasks.has(fromJid) ? `ON — ${tagallTasks.get(fromJid).botCount} bots` : 'OFF'}*`,
            `┃ 🗑️ Auto Delete: *${adInfo}*`,
            `┃ 😍 Auto React: *${autoReactEmoji || 'OFF'}*`,
            `┃ 👑 Sub-Admins: *${subAdmins.size}*`,
            `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`,
        ];
        await reply(fromJid, lines.join('\n'), m); return;
    }

    if (cmd === '/sticker') {
        await handleStickerCommand(m, parts, fromJid, senderJid, isGroup);
        return;
    }

    if (cmd === '/image') {
        await handleImageCommand(m, parts, fromJid, senderJid, isGroup);
        return;
    }

    if (cmd === '/gcpronc') {
        if (!isGroup) {
            await reply(fromJid, '❌ Use /gcpronc inside the group you want to protect.', m);
            return;
        }

        const protectedSubject = parts.slice(1).join(' ').trim();
        if (!protectedSubject) {
            await reply(fromJid, '❌ Add the group name to protect.\nExample: /gcpronc friend group\nDisable: /gcpronc off', m);
            return;
        }

        if (protectedSubject.toLowerCase() === 'off') {
            const wasProtected = gcNameProtections.delete(fromJid);
            saveState();
            await reply(fromJid, wasProtected
                ? '✅ Group name protection is off for this group.'
                : 'ℹ️ Group name protection was not enabled here.', m);
            return;
        }

        if (protectedSubject.length > 100) {
            await reply(fromJid, '❌ Group name must be 100 characters or fewer.', m);
            return;
        }

        const s = getActiveSockets(1)[0];
        if (!s) return;

        try {
            const metadata = await s.groupMetadata(fromJid);
            const botParticipant = findBotGroupParticipant(s, metadata.participants);
            if (!botParticipant || !['admin', 'superadmin'].includes(botParticipant.admin)) {
                await reply(fromJid, '❌ Bot ko pehle is group ka admin banao; tabhi name protection kaam karega.', m);
                return;
            }

            gcNameProtections.set(fromJid, protectedSubject);
            saveState();

            if (metadata.subject !== protectedSubject) {
                await s.groupUpdateSubject(fromJid, protectedSubject);
            }
            await reply(fromJid, `🛡️ Group name protection ON.\nFixed name: *${protectedSubject}*`, m);
        } catch (e) {
            await reply(fromJid, `⚠️ Protection was saved, but I couldn't set the group name right now: ${e.message}`, m);
        }
        return;
    }

    if (cmd === '/gc' && parts[1]?.toLowerCase() === 'list') {
        const s = getActiveSockets(1)[0]; if (!s) return;
        try {
            const groups  = await s.groupFetchAllParticipating();
            const entries = Object.entries(groups);
            if (!entries.length) { await reply(fromJid,'⚔️ No groups found!',m); return; }
            let txt = `┏━━〔 ⚔️ *GROUPS* 〕━━┓\n\n`;
            entries.forEach(([,g],i) => { txt += `*${i+1}.* ${g.subject}\n`; });
            txt += `\n┗━ Total: *${entries.length}* ━┛`;
            await reply(fromJid, txt, m);
        } catch(e) { await reply(fromJid,`❌ Error: ${e.message}`,m); }
        return;
    }

    if (cmd === '/gc' && parts[1] && parts[1] !== 'list' && parts.length >= 3) {
        const s = getActiveSockets(1)[0]; if (!s) return;
        const num = parseInt(parts[1]);
        const msg = parts.slice(2).join(' ');
        try {
            const entries = Object.entries(await s.groupFetchAllParticipating());
            if (isNaN(num)||num<1||num>entries.length) { await reply(fromJid,'❌ Invalid number.',m); return; }
            const [gJid,gMeta] = entries[num-1];
            await s.sendMessage(gJid,{text:msg});
            await reply(fromJid,`✅ Sent to: *${gMeta.subject}*`,m);
        } catch(e) { await reply(fromJid,`❌ Error: ${e.message}`,m); }
        return;
    }

    if (cmd === '/song') {
        const query = parts.slice(1).join(' ');
        if (!query) { await reply(fromJid,'❌ Enter song name!\nExample: /song Tum Hi Ho',m); return; }
        await reply(fromJid,`🔍 Searching JioSaavn: *${query}*...`,m);
        (async () => {
            try {
                const song = await searchJioSaavn(query);
                if (!song) { await reply(fromJid,'❌ No song found! Try a different name 🎶',m); return; }

                const s = getActiveSockets(1)[0];
                if (!s) return;

                const caption = `🎵 *${song.title}*
🎤 ${song.artist}
💿 ${song.album || 'Unknown album'}
${song.year ? `📅 ${song.year}\n` : ''}${song.duration ? `⏱️ ${song.duration}\n` : ''}${song.plays ? `▶️ ${song.plays} plays\n` : ''}🎧 ${song.bitrate} • JioSaavn

⚡ *RAJ X Mafia Bot* 💀`;
                await sendSongCover(s, fromJid, song.imageUrl, caption, m);
                const buf = await downloadBuffer(song.audioUrl);
                await s.sendMessage(fromJid, {
                    audio:    buf,
                    mimetype: 'audio/mp4',
                    fileName: `${song.title}.m4a`,
                    ptt:      false,
                    caption,
                }, { quoted: m });
            } catch(e) {
                _ol('[SONG ERROR]', e.message);
                await reply(fromJid,`❌ Song error: ${e.message}`,m);
            }
        })();
        return;
    }

    if (cmd === '/gana') {
        const query = parts.slice(1).join(' ');
        if (!query) { await reply(fromJid,'❌ Enter song name!\nExample: /gana Saiyaara',m); return; }
        await reply(fromJid,`🎵 Searching: *${query}*...`,m);
        (async () => {
            try {
                let spTrack = null;
                try { spTrack = await searchSpotify(query); } catch(e) { _ol('[SPOTIFY]', e.message); }

                const searchQuery = spTrack ? `${spTrack.title} ${spTrack.artist}` : query;

                const song = await searchJioSaavn(searchQuery);
                if (!song) { await reply(fromJid,'❌ Song not found! Try another name 🎶',m); return; }

                const s = getActiveSockets(1)[0];
                if (!s) return;

                const displayTitle  = spTrack?.title  || song.title;
                const displayArtist = spTrack?.artist || song.artist;
                const displayAlbum  = spTrack?.album  || song.album;
                const yearStr       = spTrack?.releaseYear || song.year || '';
                const imageUrl      = spTrack?.imageUrl || song.imageUrl;
                const caption = `🎵 *${displayTitle}*
🎤 ${displayArtist}
💿 ${displayAlbum || 'Unknown album'}
${yearStr ? `📅 ${yearStr}\n` : ''}${song.duration ? `⏱️ ${song.duration}\n` : ''}${song.plays ? `▶️ ${song.plays} plays\n` : ''}🎧 ${song.bitrate} • JioSaavn
🟢 Spotify metadata • JioSaavn audio

⚡ *RAJ X Mafia Bot* 💀`;
                await sendSongCover(s, fromJid, imageUrl, caption, m);
                const buf = await downloadBuffer(song.audioUrl);
                await s.sendMessage(fromJid, {
                    audio:    buf,
                    mimetype: 'audio/mp4',
                    fileName: `${displayTitle}.m4a`,
                    ptt:      false,
                    caption,
                }, { quoted: m });
            } catch(e) {
                _ol('[GANA ERROR]', e.message);
                await reply(fromJid,`❌ Song error: ${e.message}`,m);
            }
        })();
        return;
    }

    if (cmd === '/geet') {
        const query = parts.slice(1).join(' ');
        if (!query) { await reply(fromJid,'❌ Enter song name!\nExample: /geet Tum Hi Ho',m); return; }
        await reply(fromJid,`🎵 Searching on Audius: *${query}*...`,m);
        (async () => {
            try {
                const track = await searchAudius(query);
                if (!track) { await reply(fromJid,'❌ Song not found on Audius! Try another name 🎶',m); return; }

                const s = getActiveSockets(1)[0];
                if (!s) return;

                const caption = `🎵 *${track.title}*\n👤 ${track.artist}${track.duration ? `\n⏱️ ${track.duration}` : ''}\n\n🎧 *Audius — Free Music*\n⚔️ *RAJ X Mafia Bot* 💀`;
                const buf = await downloadBuffer(track.streamUrl);
                await s.sendMessage(fromJid, {
                    audio:    buf,
                    mimetype: 'audio/mp4',
                    fileName: `${track.title}.m4a`,
                    ptt:      false,
                    caption,
                }, { quoted: m });
            } catch(e) {
                _ol('[GEET ERROR]', e.message);
                await reply(fromJid,`❌ Geet error: ${e.message}`,m);
            }
        })();
        return;
    }

    if (cmd === '/spam') {
        const sub = parts[1]?.toLowerCase();
        if (sub === 'off') {
            if (stopTask(spamTasks,fromJid)) await reply(fromJid,'✅ Spam stopped! 💀',m);
            else await reply(fromJid,'ℹ️ Spam was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<100) { await reply(fromJid,'❌ Min 100ms required.',m); return; }
            spamDelays.set(fromJid,ms); saveState();
            await reply(fromJid,`✅ Spam delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!spamTasks.has(fromJid)) { await reply(fromJid,'🔥 Spam: *OFF*',m); return; }
            const t = spamTasks.get(fromJid);
            await reply(fromJid,`╔══〔 🔥 *SPAM INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per msg\n┃ Message: ${t.message}\n╚══════════════════╝`,m); return;
        }
        const botCount = /^[1-4]$/.test(sub) ? clampBots(sub) : 1;
        const msgStart = /^[1-4]$/.test(sub) ? 2 : 1;
        const spamMsg  = parts.slice(msgStart).join(' ');
        if (!spamMsg) { await reply(fromJid,'❌ Enter message!\nExample: /spam2 Hello',m); return; }
        await reply(fromJid, startSpam(fromJid, botCount, spamMsg, getDelay(spamDelays,fromJid,DEFAULT_SPAM_DELAY)), m);
        return;
    }

    if (cmd === '/rspam') {
        const sub = parts[1]?.toLowerCase();
        if (sub === 'off') {
            if (stopTask(rspamTasks,fromJid)) await reply(fromJid,'✅ Reply spam stopped! 💀',m);
            else await reply(fromJid,'ℹ️ Reply spam was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<100) { await reply(fromJid,'❌ Min 100ms required.',m); return; }
            spamDelays.set('rspam:'+fromJid, ms); saveState();
            await reply(fromJid,`✅ Reply spam delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!rspamTasks.has(fromJid)) { await reply(fromJid,'💬 Reply Spam: *OFF*',m); return; }
            const t = rspamTasks.get(fromJid);
            await reply(fromJid,`╔══〔 💬 *REPLY SPAM INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per reply\n┃ Message: ${t.message}\n╚══════════════════╝`,m); return;
        }

        const ctx = m.message?.extendedTextMessage?.contextInfo;
        if (!ctx?.quotedMessage) {
            await reply(fromJid,'❌ First *quote/reply* a message, then type /rspam2 <msg>!',m); return;
        }
        const quotedKey = {
            remoteJid: fromJid,
            fromMe: ctx.participant === jidNormalizedUser(getActiveSockets(1)[0]?.user?.id||''),
            id: ctx.stanzaId,
            participant: ctx.participant,
        };

        const botCount = /^[1-4]$/.test(sub) ? clampBots(sub) : 1;
        const msgStart = /^[1-4]$/.test(sub) ? 2 : 1;
        const rspamMsg = parts.slice(msgStart).join(' ');
        if (!rspamMsg) { await reply(fromJid,'❌ Enter message!\nExample: /rspam2 Lol',m); return; }
        const d = getDelay(spamDelays, 'rspam:'+fromJid, DEFAULT_SPAM_DELAY);
        await reply(fromJid, startRspam(fromJid, botCount, rspamMsg, d, quotedKey), m);
        return;
    }

    if (cmd === '/pollspam') {
        const sub = parts[1]?.toLowerCase();
        if (sub === 'off') {
            if (stopTask(pollTasks,fromJid)) await reply(fromJid,'✅ Poll spam stopped! 💀',m);
            else await reply(fromJid,'ℹ️ Poll spam was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<500) { await reply(fromJid,'❌ Min 500ms required.',m); return; }
            spamDelays.set('poll:'+fromJid, ms); saveState();
            await reply(fromJid,`✅ Poll spam delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!pollTasks.has(fromJid)) { await reply(fromJid,'📊 Poll Spam: *OFF*',m); return; }
            const t = pollTasks.get(fromJid);
            const custom = pollOptions.get(fromJid);
            const optsLine = custom ? `\n┃ Options: ${custom.join(' | ')}` : '';
            await reply(fromJid,`╔══〔 📊 *POLL SPAM INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per poll\n┃ Topic: ${t.topic}${optsLine}\n╚══════════════════╝`,m); return;
        }
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const botCount  = /^[1-4]$/.test(sub) ? clampBots(sub) : 1;
        const topStart  = /^[1-4]$/.test(sub) ? 2 : 1;
        const topic     = parts.slice(topStart).join(' ');
        if (!topic) { await reply(fromJid,'❌ Enter topic!\nExample: /pollspam2 Vote now',m); return; }
        const d = getDelay(spamDelays, 'poll:'+fromJid, 3000);
        await reply(fromJid, startPollSpam(fromJid, botCount, topic, d), m);
        return;
    }

    if (cmd === '/oppoll') {
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const input = parts.slice(1).join(' ').trim();

        if (input.toLowerCase() === 'off' || input.toLowerCase() === 'clear') {
            pollOptions.delete(fromJid); saveState();
            await reply(fromJid,'✅ Custom poll options cleared! /pollspam will use auto-numbered options.',m); return;
        }
        if (input.toLowerCase() === 'list' || input.toLowerCase() === 'info') {
            const cur = pollOptions.get(fromJid);
            if (!cur) { await reply(fromJid,'ℹ️ No custom options set.\nUse: /oppoll option1 | option2 | ...',m); return; }
            await reply(fromJid,`╔══〔 📊 *POLL OPTIONS* 〕══╗\n${cur.map((o,i)=>`┃ ${i+1}. ${o}`).join('\n')}\n╚══════════════════╝`,m); return;
        }
        if (!input) {
            await reply(fromJid,'❌ Enter options!\nFormat: /oppoll Option1 | Option2 | Option3\nMax 8 options, separate with pipe (|)\n\nExample:\n/oppoll Rahul | Priya | Riya | Mafia',m); return;
        }

        const opts = input.split('|').map(o=>o.trim()).filter(o=>o.length>0);
        if (opts.length < 2) { await reply(fromJid,'❌ At least 2 options required!\nFormat: /oppoll Option1 | Option2 | Option3',m); return; }
        if (opts.length > 8) { await reply(fromJid,'❌ Max 8 options allowed! You gave: '+opts.length,m); return; }

        pollOptions.set(fromJid, opts); saveState();
        const preview = `╔══〔 ✅ *POLL OPTIONS SET* 〕══╗\n${opts.map((o,i)=>`┃ ${i+1}. ${o}`).join('\n')}\n╚══════════════════╝\n\n_These options will now be used in /pollspam!_`;
        await reply(fromJid, preview, m); return;
    }

    if (cmd === '/pfp') {
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const sub = parts[1]?.toLowerCase();

        if (sub === 'off') {
            if (stopTask(pfpTasks,fromJid)) await reply(fromJid,'✅ PFP change stopped! 💀',m);
            else await reply(fromJid,'ℹ️ PFP change was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<2000) { await reply(fromJid,'❌ Min 2000ms required (WA rate limit).',m); return; }
            pfpDelays.set(fromJid,ms); saveState();
            await reply(fromJid,`✅ PFP delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!pfpTasks.has(fromJid)) { await reply(fromJid,'🖼️ PFP Change: *OFF*',m); return; }
            const t = pfpTasks.get(fromJid);
            await reply(fromJid,`╔══〔 🖼️ *PFP INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per change\n╚══════════════════╝`,m); return;
        }

        const _um  = m.message?.deviceSentMessage?.message || m.message;
        const _ctx = _um?.extendedTextMessage?.contextInfo
                  || _um?.imageMessage?.contextInfo
                  || _um?.videoMessage?.contextInfo;
        const imgMsg =
            _um?.imageMessage                                   ||
            _um?.viewOnceMessage?.message?.imageMessage         ||
            _um?.viewOnceMessageV2?.message?.imageMessage       ||
            _um?.viewOnceMessageV2Extension?.message?.imageMessage ||
            _ctx?.quotedMessage?.imageMessage                   ||
            null;

        _ol(`[PFP] keys=${Object.keys(_um||{}).join(',')} imgMsg=${!!imgMsg} mediaKey=${!!imgMsg?.mediaKey} url=${!!imgMsg?.url}`);

        if (!imgMsg) {
            await reply(fromJid,
                '❌ Image required!\n\n*2 ways:*\n1️⃣ Send image with caption: */pfp* or */pfp2*\n2️⃣ Quote an image and type /pfp',m);
            return;
        }

        await reply(fromJid,'⬇️ Downloading image...',m);
        try {
            let buf = null;

            try {
                const stream = await downloadContentFromMessage(imgMsg, 'image');
                const chunks = [];
                for await (const chunk of stream) chunks.push(chunk);
                const b = Buffer.concat(chunks);
                if (b.length > 0) buf = b;
                _ol('[PFP] Method1 success, bytes:', buf?.length);
            } catch(e1) {
                _ol('[PFP] Method1 failed:', e1.message, '— trying Method2 (direct URL)');
            }

            if (!buf && imgMsg.url) {
                try {
                    buf = await downloadBuffer(imgMsg.url);
                    _ol('[PFP] Method2 success, bytes:', buf?.length);
                } catch(e2) {
                    _ol('[PFP] Method2 failed:', e2.message);
                }
            }

            if (!buf || !buf.length) throw new Error('Both methods failed, image not found');

            const pfpFile = `./pfp_${fromJid.replace(/[^a-z0-9]/gi,'_')}.jpg`;
            fs.writeFileSync(pfpFile, buf);

            const botCount = /^[1-4]$/.test(sub) ? clampBots(sub) : 1;
            const d        = getDelay(pfpDelays, fromJid, DEFAULT_PFP_DELAY);
            const result   = startPfpChange(fromJid, botCount, pfpFile, d);
            await reply(fromJid, result || '✅ PFP change started!', m);
        } catch(e) {
            _ol('[PFP ERROR]', e.message);
            await reply(fromJid,`❌ Download failed: ${e.message}`,m);
        }
        return;
    }

    if (cmd === '/pinspam') {
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const sub = parts[1]?.toLowerCase();

        if (sub === 'off') {
            if (stopTask(pinspamTasks,fromJid)) await reply(fromJid,'✅ Pin spam stopped! 💀',m);
            else await reply(fromJid,'ℹ️ Pin spam was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<500) { await reply(fromJid,'❌ Min 500ms required.',m); return; }
            pinspamDelays.set(fromJid,ms); saveState();
            await reply(fromJid,`✅ Pin spam delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'count') {
            const n = parseInt(parts[2]);
            if (isNaN(n)||n<1||n>50) { await reply(fromJid,'❌ Count must be between 1–50.',m); return; }
            pinCounts.set(fromJid,n); saveState();
            await reply(fromJid,`✅ Pin count: *${n} msgs → pin*`,m); return;
        }
        if (sub === 'info') {
            if (!pinspamTasks.has(fromJid)) { await reply(fromJid,'📌 Pin Spam: *OFF*',m); return; }
            const t = pinspamTasks.get(fromJid);
            await reply(fromJid,`╔══〔 📌 *PIN SPAM INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Msgs per cycle: *${t.count}*\n┃ Delay: *${msToSec(t.delay)}* per msg\n┃ Msg: ${t.message}\n╚══════════════════╝`,m); return;
        }

        const botCount  = /^[1-4]$/.test(sub) ? clampBots(sub) : 1;
        const msgStart  = /^[1-4]$/.test(sub) ? 2 : 1;
        const pinMsg    = parts.slice(msgStart).join(' ');
        if (!pinMsg) { await reply(fromJid,'❌ Message do!\nExample: /pinspam2 RAJ X Mafia ⚔️',m); return; }
        const d     = getDelay(pinspamDelays, fromJid, DEFAULT_PINSPAM_DELAY);
        const count = pinCounts.has(fromJid) ? pinCounts.get(fromJid) : DEFAULT_PIN_COUNT;
        await reply(fromJid, startPinSpam(fromJid, botCount, pinMsg, d, count), m);
        return;
    }

    if (cmd === '/tagall') {
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const sub = parts[1]?.toLowerCase();

        if (sub === 'off') {
            if (stopTask(tagallTasks,fromJid)) await reply(fromJid,'✅ Tag all stopped! 💀',m);
            else await reply(fromJid,'ℹ️ Tag all was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<1000) { await reply(fromJid,'❌ Min 1000ms required.',m); return; }
            tagallDelays.set(fromJid,ms); saveState();
            await reply(fromJid,`✅ Tag all delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!tagallTasks.has(fromJid)) { await reply(fromJid,'👥 Tag All: *OFF*',m); return; }
            const t = tagallTasks.get(fromJid);
            await reply(fromJid,`╔══〔 👥 *TAG ALL INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per cycle\n┃ Msg: ${t.message||'(tags only)'}\n╚══════════════════╝`,m); return;
        }

        const botCount = /^[1-4]$/.test(sub) ? clampBots(sub) : 1;
        const msgStart = /^[1-4]$/.test(sub) ? 2 : 1;
        const tagMsg   = parts.slice(msgStart).join(' ') || '';
        const d        = getDelay(tagallDelays, fromJid, DEFAULT_TAGALL_DELAY);
        await reply(fromJid, startTagAll(fromJid, botCount, tagMsg, d), m);
        return;
    }

    if (!isGroup && (cmd==='/nc'||cmd==='/dc'||(cmd==='/auto'&&parts[1]==='delete'))) {
        await reply(fromJid,'❌ Only works in groups!',m); return;
    }

    if (cmd === '/nc') {
        const sub = parts[1]?.toLowerCase();
        if (sub === 'off') {
            if (stopTask(ncTasks,fromJid)) await reply(fromJid,'✅ NC stopped! 💀',m);
            else await reply(fromJid,'ℹ️ NC was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<100) { await reply(fromJid,'❌ Min 100ms required.',m); return; }
            ncDelays.set(fromJid,ms); saveState();
            await reply(fromJid,`✅ NC delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!ncTasks.has(fromJid)) { await reply(fromJid,'✏️ NC: *OFF*',m); return; }
            const t = ncTasks.get(fromJid);
            await reply(fromJid,`╔══〔 ✏️ *NC INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per change\n┃ Name: ${t.baseName}\n╚══════════════════╝`,m); return;
        }
        const botCount  = /^[1-4]$/.test(sub) ? clampBots(sub) : 1;
        const nameStart = /^[1-4]$/.test(sub) ? 2 : 1;
        const baseName  = parts.slice(nameStart).join(' ');
        if (!baseName) { await reply(fromJid,'❌ Enter name!\nExample: /nc2 RAJ X Mafia',m); return; }
        await reply(fromJid, startNc(fromJid, botCount, baseName, getDelay(ncDelays,fromJid,DEFAULT_NC_DELAY)), m);
        return;
    }

    if (cmd === '/dc') {
        const sub = parts[1]?.toLowerCase();
        if (sub === 'off') {
            if (stopTask(dcTasks,fromJid)) await reply(fromJid,'✅ DC stopped! 💀',m);
            else await reply(fromJid,'ℹ️ DC was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<100) { await reply(fromJid,'❌ Min 100ms required.',m); return; }
            dcDelays.set(fromJid,ms); saveState();
            await reply(fromJid,`✅ DC delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!dcTasks.has(fromJid)) { await reply(fromJid,'📝 DC: *OFF*',m); return; }
            const t = dcTasks.get(fromJid);
            await reply(fromJid,`╔══〔 📝 *DC INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per change\n┃ Desc: ${t.baseDesc}\n╚══════════════════╝`,m); return;
        }
        const botCount  = /^[1-4]$/.test(sub) ? clampBots(sub) : 1;
        const descStart = /^[1-4]$/.test(sub) ? 2 : 1;
        const baseDesc  = parts.slice(descStart).join(' ');
        if (!baseDesc) { await reply(fromJid,'❌ Enter description!\nExample: /dc4 RAJ X Mafia',m); return; }
        await reply(fromJid, startDc(fromJid, botCount, baseDesc, getDelay(dcDelays,fromJid,DEFAULT_DC_DELAY)), m);
        return;
    }

    if (cmd === '/auto' && parts[1]?.toLowerCase() === 'delete') {
        const arg = parts[2];

        if (arg?.toLowerCase() === 'off') {
            autoDeleteTargets.delete(fromJid); saveState();
            await reply(fromJid,'✅ Auto-delete all stopped! 💀',m); return;
        }

        if (arg?.toLowerCase() === 'remove' && parts[3]) {
            const phone = parts[3].replace(/\D/g,'');
            const set   = autoDeleteTargets.get(fromJid);
            if (set) { set.delete(phone); if (!set.size) autoDeleteTargets.delete(fromJid); saveState(); }
            await reply(fromJid,`✅ Target removed: *${phone}*`,m); return;
        }

        if (!arg || arg === 'info') {
            const set = autoDeleteTargets.get(fromJid);
            if (!set?.size) { await reply(fromJid,'🗑️ Auto Delete: *OFF*',m); return; }
            await reply(fromJid,`╔══〔 🗑️ *AUTO DELETE INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Targets: *${[...set].join(', ')}*\n╚══════════════════╝`,m); return;
        }

        const phone = arg.replace(/\D/g,'');
        if (!autoDeleteTargets.has(fromJid)) autoDeleteTargets.set(fromJid, new Set());
        autoDeleteTargets.get(fromJid).add(phone);
        saveState();
        const all = [...autoDeleteTargets.get(fromJid)].join(', ');
        await reply(fromJid,`╔══〔 🗑️ *AUTO DELETE ON* 〕══╗\n┃ Targets: *${all}*\n┃ Their messages will be instantly deleted\n╚══════════════════╝`,m);
        return;
    }

    if (cmd === '/auto' && parts[1]?.toLowerCase() === 'info') {
        const set = autoDeleteTargets.get(fromJid);
        if (!set?.size) { await reply(fromJid,'🗑️ Auto Delete: *OFF*',m); return; }
        await reply(fromJid,`╔══〔 🗑️ *AUTO DELETE INFO* 〕══╗\n┃ Targets: *${[...set].join(', ')}*\n╚══════════════════╝`,m); return;
    }

    if (cmd === '/antilink') {
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const sub = parts[1]?.toLowerCase();
        if (sub === 'on') {
            antilinkGroups.add(fromJid); saveState();
            await reply(fromJid,'╔══〔 🔗 *ANTILINK ON* 〕══╗\n┃ Anyone who sends a link in this group\n┃ will have their message *auto-deleted* ✅\n╚══════════════════╝',m);
        } else if (sub === 'off') {
            antilinkGroups.delete(fromJid); saveState();
            await reply(fromJid,'✅ Antilink disabled! 🔓',m);
        } else if (sub === 'info') {
            const on = antilinkGroups.has(fromJid);
            await reply(fromJid,`╔══〔 🔗 *ANTILINK INFO* 〕══╗\n┃ Status: *${on ? 'ON ✅' : 'OFF ❌'}*\n╚══════════════════╝`,m);
        } else {
            await reply(fromJid,'❌ Use: */antilink on* | */antilink off* | */antilink info*',m);
        }
        return;
    }

    if (cmd === '/solo') {
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const sub = parts[1]?.toLowerCase();
        if (sub === 'off') {
            if (stopTask(soloTasks, fromJid)) await reply(fromJid,'✅ Solo loop stopped! 💀',m);
            else await reply(fromJid,'ℹ️ Solo was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<500) { await reply(fromJid,'❌ Min 500ms required.',m); return; }
            soloDelays.set(fromJid, ms); saveState();
            await reply(fromJid,`✅ Solo delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!soloTasks.has(fromJid)) { await reply(fromJid,'🔒 Solo: *OFF*',m); return; }
            const t = soloTasks.get(fromJid);
            await reply(fromJid,`╔══〔 🔒 *SOLO INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per toggle\n╚══════════════════╝`,m); return;
        }
        const botCountMatch = /^[1-4]$/.test(sub);
        const botCount = botCountMatch ? clampBots(sub) : 1;
        if (sub !== 'on' && !botCountMatch) {
            await reply(fromJid,'❌ Use: */solo on* | */solo1–4* | */solo off* | */solo delay <ms>* | */solo info*',m); return;
        }
        const d = getDelay(soloDelays, fromJid, DEFAULT_SOLO_DELAY);
        await reply(fromJid, startSolo(fromJid, botCount, d), m);
        return;
    }

    if (cmd === '/s2') {
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const sub = parts[1]?.toLowerCase();
        if (sub === 'off') {
            if (stopTask(s2Tasks, fromJid)) await reply(fromJid,'✅ S2 loop stopped! 💀',m);
            else await reply(fromJid,'ℹ️ S2 was not running.',m);
            return;
        }
        if (sub === 'delay') {
            const ms = parseInt(parts[2]);
            if (isNaN(ms)||ms<500) { await reply(fromJid,'❌ Min 500ms required.',m); return; }
            s2Delays.set(fromJid, ms); saveState();
            await reply(fromJid,`✅ S2 delay: *${msToSec(ms)}*`,m); return;
        }
        if (sub === 'info') {
            if (!s2Tasks.has(fromJid)) { await reply(fromJid,'💬 S2: *OFF*',m); return; }
            const t = s2Tasks.get(fromJid);
            await reply(fromJid,`╔══〔 💬 *S2 INFO* 〕══╗\n┃ Status: *ON* ✅\n┃ Bots: *${t.botCount}/${MAX_BOTS}*\n┃ Speed: *${msToSec(t.delay)}* per toggle\n╚══════════════════╝`,m); return;
        }
        const botCountMatch = /^[1-4]$/.test(sub);
        const botCount = botCountMatch ? clampBots(sub) : 1;
        if (sub !== 'on' && !botCountMatch) {
            await reply(fromJid,'❌ Use: */s2 on* | */s21–4* | */s2 off* | */s2 delay <ms>* | */s2 info*',m); return;
        }
        const d = getDelay(s2Delays, fromJid, DEFAULT_S2_DELAY);
        await reply(fromJid, startS2(fromJid, botCount, d), m);
        return;
    }

    if (cmd === '/stopall') {
        const maps = [
            [spamTasks,    '📨 Spam'],
            [rspamTasks,   '💬 Reply Spam'],
            [pollTasks,    '📊 Poll Spam'],
            [ncTasks,      '✏️ NC'],
            [dcTasks,      '📝 DC'],
            [pfpTasks,     '🖼️ PFP'],
            [pinspamTasks, '📌 Pin Spam'],
            [tagallTasks,  '👥 Tag All'],
            [soloTasks,    '🔒 Solo'],
            [s2Tasks,      '💬 S2'],
        ];
        const stopped = new Set();
        for (const [map, label] of maps) {
            for (const [gid, task] of map) {
                task.runners.forEach(r => r.stop());
                map.delete(gid);
                stopped.add(label);
            }
        }
        saveState();
        if (stopped.size === 0) {
            await reply(fromJid,'ℹ️ No tasks were running!',m);
        } else {
            const list = [...stopped].map(s => `┃ ${s}: *OFF* ✅`).join('\n');
            await reply(fromJid,`╔══〔 💀 *STOPALL* 〕══╗\n${list}\n╚══════════════════╝`,m);
        }
        return;
    }

    if (cmd === '/react') {
        if (!parts[1]) { await reply(fromJid,'❌ Enter emoji. Example: /react ⚔️',m); return; }
        autoReactEmoji = parts[1]; randomReactChats.clear(); saveState();
        await reply(fromJid,`✅ Auto-react: *${autoReactEmoji}*`,m); return;
    }
    if (cmd === '/stopreact') { autoReactEmoji=null; saveState(); await reply(fromJid,'✅ Auto-react stopped!',m); return; }

    if (cmd === '/reaction') {
        const sub = parts[1]?.toLowerCase();
        if (sub === 'off') {
            randomReactChats.delete(fromJid); saveState();
            await reply(fromJid,'✅ Random reaction stopped here!',m); return;
        }
        randomReactChats.add(fromJid); autoReactEmoji = null; saveState();
        await reply(fromJid,`╔══〔 🎲 *RANDOM REACTION ON* 〕══╗\n┃ Only active in *this chat* ✅\n┃ Pool: ❤️ 😂 🔥 💀 ⚔️ 😎 🤣 👀 💯 🫡 🥶 😈...\n╚══════════════════╝\n_Use /reaction off to stop_`,m); return;
    }

    if (cmd === '/addsubadmin') {
        if (!isOwner(senderJid)) { await reply(fromJid,'❌ Owner only!',m); return; }
        const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid||[];
        if (!mentioned.length) { await reply(fromJid,'❌ Tag someone.',m); return; }
        const added=[];
        mentioned.forEach(j=>{const n=jidNormalizedUser(j);subAdmins.add(n);added.push(jidToNum(n));});
        saveState(); await reply(fromJid,`✅ Sub-admin added: ${added.join(', ')}`,m); return;
    }
    if (cmd === '/removesubadmin') {
        if (!isOwner(senderJid)) { await reply(fromJid,'❌ Owner only!',m); return; }
        const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid||[];
        if (!mentioned.length) { await reply(fromJid,'❌ Tag someone.',m); return; }
        const removed=[];
        mentioned.forEach(j=>{const n=jidNormalizedUser(j);subAdmins.delete(n);removed.push(jidToNum(n));});
        saveState(); await reply(fromJid,`✅ Removed: ${removed.join(', ')}`,m); return;
    }
    if (cmd === '/listsubadmin') {
        if (!subAdmins.size) { await reply(fromJid,'⚔️ No sub-admins!',m); return; }
        let txt='┏━━〔 ⚔️ *SUB-ADMINS* 〕━━┓\n\n'; let i=1;
        subAdmins.forEach(j=>{txt+=`*${i++}.* ${jidToNum(j)}\n`;});
        await reply(fromJid,txt.trim(),m); return;
    }

    if (cmd === '/remove') {
        if (!isGroup) { await reply(fromJid,'❌ Only works in groups!',m); return; }
        const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (!mentioned.length) { await reply(fromJid,'❌ Tag someone!\nExample: /remove @someone',m); return; }
        const s = getActiveSockets(1)[0];
        if (!s) { await reply(fromJid,'❌ Bot not connected!',m); return; }
        const results = [];
        for (const jid of mentioned) {
            try {
                await s.groupParticipantsUpdate(fromJid, [jid], 'remove');
                results.push(`✅ *${jidToNum(jid)}* removed successfully`);
            } catch(e) {
                results.push(`❌ *${jidToNum(jid)}* — ${e.message?.includes('not-authorized') ? 'Bot is not admin!' : 'Failed'}`);
            }
        }
        await reply(fromJid, `╔══〔 🚫 *REMOVE* 〕══╗\n${results.map(r=>`┃ ${r}`).join('\n')}\n╚══════════════════╝`, m);
        return;
    }

    if (cmd === '/ar') {
        const sub = parts[1]?.toLowerCase();

        if (sub === 'list' || sub === 'info') {
            if (!autoReplyTargets.size) { await reply(fromJid,'💬 Auto Reply: *OFF*',m); return; }
            let txt = `╔══〔 💬 *AUTO REPLY LIST* 〕══╗\n`;
            let i = 1;
            autoReplyTargets.forEach((msg, num) => { txt += `┃ ${i++}. *${num}* → ${msg}\n`; });
            txt += `╚══════════════════╝`;
            await reply(fromJid, txt, m); return;
        }

        if (sub === 'off' && parts[2]?.toLowerCase() === 'all') {
            autoReplyTargets.clear(); saveState();
            await reply(fromJid,'✅ All auto replies cleared! 💀',m); return;
        }

        if (sub === 'off' && parts[2]) {
            const phone = normalizePhoneNumber(parts[2]);
            if (phone.length < 8 || phone.length > 15) {
                await reply(fromJid,'❌ Give a valid number with country code.',m); return;
            }
            autoReplyTargets.delete(phone); saveState();
            await reply(fromJid,`✅ Auto reply OFF: *${phone}*`,m); return;
        }

        if (sub && /^[+\d().-]+$/.test(sub)) {
            const phone = normalizePhoneNumber(sub);
            if (phone.length < 8 || phone.length > 15) {
                await reply(fromJid,'❌ Give a valid number with country code (8-15 digits).',m); return;
            }
            const msg   = parts.slice(2).join(' ');
            if (!msg) { await reply(fromJid,'❌ Enter a message too!\nFormat: /ar +919876543210 I am busy right now',m); return; }
            autoReplyTargets.set(phone, msg); saveState();
            await reply(fromJid,`╔══〔 💬 *AUTO REPLY ON* 〕══╗\n┃ Number: *${phone}*\n┃ Reply: ${msg}\n╚══════════════════╝`,m); return;
        }

        await reply(fromJid,`❌ Format:\n*/ar +919876543210 <message>*\n*/ar off +919876543210*\n*/ar off all*\n*/ar list*`,m);
        return;
    }

    if (cmd === '/target') {
        if (!isGroup) { await reply(fromJid,'❌ /target only works inside a group!',m); return; }

        const sub = parts[1]?.toLowerCase();

        if (sub === 'list') {
            const set = targetedUsers.get(fromJid);
            if (!set?.size) { await reply(fromJid,'🎯 No targets set in this group.',m); return; }
            let txt = `╔══〔 🎯 *TARGETED USERS* 〕══╗\n`;
            let i = 1;
            set.forEach(num => { txt += `┃ ${i++}. 📍 *${num}*\n`; });
            txt += `╚══════════════════╝`;
            await reply(fromJid, txt, m); return;
        }

        if (sub === 'off' && parts[2]?.toLowerCase() === 'all') {
            targetedUsers.delete(fromJid); saveState();
            await reply(fromJid,'✅ All targets removed from this group!',m); return;
        }

        if (sub === 'off') {
            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
            const nums = mentioned.length
                ? mentioned.map(j => jidToNum(j).replace(/\D/g,''))
                : [parts[2]?.replace(/\D/g,'')].filter(Boolean);
            if (!nums.length) { await reply(fromJid,'❌ Mention someone or give a number!\nExample: /target off @user',m); return; }
            const set = targetedUsers.get(fromJid);
            nums.forEach(n => set?.delete(n));
            if (!set?.size) targetedUsers.delete(fromJid);
            saveState();
            await reply(fromJid,`✅ Removed ${nums.length} target(s)!`,m); return;
        }

        const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        if (!mentioned.length) {
            await reply(fromJid,'❌ Mention at least one person!\nExample: /target @someone',m); return;
        }
        if (!targetedUsers.has(fromJid)) targetedUsers.set(fromJid, new Set());
        const set = targetedUsers.get(fromJid);
        const added = [];
        mentioned.forEach(j => {
            const num = jidToNum(j).replace(/\D/g,'');
            set.add(num);
            added.push(num);
        });
        saveState();
        let txt = `╔══〔 🎯 *TARGET SET* 〕══╗\n`;
        added.forEach(n => { txt += `┃ 📍 *${n}* — will get random replies\n`; });
        txt += `╚══════════════════╝\n_Use /target off @user to remove_`;
        await reply(fromJid, txt, m); return;
    }
}

function stopMediaSends(groupJid, type) {
    let stopped = 0;
    for (const task of mediaSendTasks.values()) {
        if (task.groupJid !== groupJid || task.type !== type) continue;
        task.stopped = true;
        task.cancelDelay?.();
        stopped++;
    }
    return stopped;
}

function waitForMediaSendDelay(delayMs, task) {
    return new Promise(resolve => {
        let settled = false;
        const finish = () => {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            if (task.cancelDelay === finish) task.cancelDelay = null;
            resolve();
        };
        const timer = setTimeout(finish, delayMs);
        task.cancelDelay = finish;
    });
}

function startMediaSendLoop(taskKey, task, send, getDelay, onError) {
    void (async () => {
        try {
            while (!task.stopped) {
                await send();
                if (!task.stopped) await waitForMediaSendDelay(getDelay(), task);
            }
        } catch (e) {
            try {
                await onError(e);
            } catch (replyError) {
                console.error('[Media send error]', e.message, replyError.message);
            }
        } finally {
            if (mediaSendTasks.get(taskKey) === task) mediaSendTasks.delete(taskKey);
        }
    })();
}

// /------------------------ STICKER COMMAND CODE ----------------------------/
async function handleStickerCommand(m, parts, fromJid, senderJid, isGroup) {
    if (!isGroup) {
        await reply(fromJid, '❌ Sticker save/send commands work only inside a group.', m);
        return;
    }

    const action = (parts[1] || '').toLowerCase();
    if (action === 'off') {
        if (parts.length !== 2) {
            await reply(fromJid, '❌ Use /sticker off with no extra arguments.', m);
            return;
        }
        const stopped = stopMediaSends(fromJid, 'sticker');
        await reply(fromJid, stopped
            ? '✅ Sticker sending stopped.'
            : 'ℹ️ No sticker send is currently running.', m);
        return;
    }

    if (action === 'delay') {
        if (parts.length === 2) {
            const delayMs = mediaSendDelays.get(`${fromJid}:sticker`) ?? DEFAULT_MEDIA_SEND_DELAY_MS;
            await reply(fromJid, `⏱️ Sticker repeat delay: *${delayMs} ms* (${msToSec(delayMs)}).`, m);
            return;
        }
        const delayArg = parts[2] || '';
        if (!/^\d+$/.test(delayArg) || parts.length !== 3) {
            await reply(fromJid, `❌ Use /sticker delay <milliseconds> (${MIN_MEDIA_SEND_DELAY_MS}-${MAX_MEDIA_SEND_DELAY_MS}).`, m);
            return;
        }
        const delayMs = Number(delayArg);
        if (delayMs < MIN_MEDIA_SEND_DELAY_MS || delayMs > MAX_MEDIA_SEND_DELAY_MS) {
            await reply(fromJid, `❌ Sticker delay must be ${MIN_MEDIA_SEND_DELAY_MS}-${MAX_MEDIA_SEND_DELAY_MS} ms.`, m);
            return;
        }
        mediaSendDelays.set(`${fromJid}:sticker`, delayMs);
        saveState();
        await reply(fromJid, `✅ Sticker repeat delay set to *${delayMs} ms* (${msToSec(delayMs)}).`, m);
        return;
    }

    if (action === 'cooldown') {
        const secondsArg = parts[2] || '';
        if (!/^\d+$/.test(secondsArg) || parts.length !== 3) {
            await reply(fromJid, `❌ Use /sticker cooldown <seconds> (${MIN_MEDIA_COOLDOWN_SECONDS}-${MAX_MEDIA_COOLDOWN_SECONDS}).`, m);
            return;
        }
        const seconds = Number(secondsArg);
        if (seconds < MIN_MEDIA_COOLDOWN_SECONDS || seconds > MAX_MEDIA_COOLDOWN_SECONDS) {
            await reply(fromJid, `❌ Cooldown must be ${MIN_MEDIA_COOLDOWN_SECONDS}-${MAX_MEDIA_COOLDOWN_SECONDS} seconds.`, m);
            return;
        }
        mediaCooldowns.set(fromJid, seconds);
        saveState();
        await reply(fromJid, `✅ Sticker/image cooldown set to *${seconds}s* for this group.`, m);
        return;
    }

    if (action === 'save' || action === 'savs') {
        const idArg = parts[2] || '';
        if (!/^[1-9]\d{0,2}$/.test(idArg)) {
            await reply(fromJid, '❌ Use /sticker save <1-999> while replying to a sticker.\nExample: /sticker save 1', m);
            return;
        }

        const commandMessage = m.message?.deviceSentMessage?.message || m.message || {};
        const quotedMessage = commandMessage.extendedTextMessage?.contextInfo?.quotedMessage;
        const stickerMessage = quotedMessage?.stickerMessage;
        if (!stickerMessage) {
            await reply(fromJid, '❌ Reply to a sticker with /sticker save <id>.', m);
            return;
        }

        const id = String(Number(idArg));
        const groupStickers = savedStickers.get(fromJid) || new Set();
        if (!groupStickers.has(id) && groupStickers.size >= MAX_STICKERS_PER_GROUP) {
            await reply(fromJid, `❌ This group already has ${MAX_STICKERS_PER_GROUP} saved stickers.`, m);
            return;
        }

        try {
            const stream = await downloadContentFromMessage(stickerMessage, 'sticker');
            const chunks = [];
            let totalBytes = 0;
            for await (const chunk of stream) {
                totalBytes += chunk.length;
                if (totalBytes > MAX_STICKER_BYTES) {
                    throw new Error('Sticker is larger than 2 MB.');
                }
                chunks.push(chunk);
            }
            if (!totalBytes) throw new Error('Sticker download was empty.');

            fs.mkdirSync(STICKER_DIR, { recursive: true });
            fs.writeFileSync(getSavedStickerPath(fromJid, id), Buffer.concat(chunks));
            groupStickers.add(id);
            savedStickers.set(fromJid, groupStickers);
            saveState();
            await reply(fromJid, `✅ Sticker saved as *${id}* in this group.`, m);
        } catch (e) {
            await reply(fromJid, `❌ Couldn't save that sticker: ${e.message}`, m);
        }
        return;
    }

    const idArg = parts[1] || '';
    if (!/^[1-9]\d{0,2}$/.test(idArg) || parts.length !== 2) {
        await reply(fromJid, '❌ Use /sticker <id> to start sending, then /sticker off to stop.\nExample: /sticker 1', m);
        return;
    }

    const id = String(Number(idArg));
    const groupStickers = savedStickers.get(fromJid);
    const stickerPath = getSavedStickerPath(fromJid, id);
    if (!groupStickers?.has(id) || !fs.existsSync(stickerPath)) {
        await reply(fromJid, `❌ Sticker *${id}* isn't saved in this group. Reply to a sticker with /sticker save ${id} first.`, m);
        return;
    }

    const taskKey = `${fromJid}:sticker`;
    if (mediaSendTasks.has(taskKey)) {
        await reply(fromJid, '⏳ A sticker loop is already running in this group. Use /sticker off to stop it.', m);
        return;
    }

    const cooldownKey = `${fromJid}:${jidToNum(senderJid)}`;
    const now = Date.now();
    const cooldownMs = (mediaCooldowns.get(fromJid) ?? DEFAULT_MEDIA_COOLDOWN_SECONDS) * 1000;
    const elapsed = now - (mediaSendLastAt.get(cooldownKey) || 0);
    if (elapsed < cooldownMs) {
        const waitSeconds = Math.ceil((cooldownMs - elapsed) / 1000);
        await reply(fromJid, `⏳ Wait ${waitSeconds}s before sending another saved image/sticker.`, m);
        return;
    }
    mediaSendLastAt.set(cooldownKey, now);

    const s = getActiveSockets(1)[0];
    if (!s) return;
    let sticker;
    try {
        sticker = fs.readFileSync(stickerPath);
    } catch (e) {
        await reply(fromJid, `❌ Couldn't send the saved sticker: ${e.message}`, m);
        return;
    }

    const task = { groupJid: fromJid, type: 'sticker', stopped: false, cancelDelay: null };
    mediaSendTasks.set(taskKey, task);
    try {
        await reply(fromJid, '▶️ Sticker loop started. Use /sticker off to stop it.', m);
    } catch (e) {
        if (mediaSendTasks.get(taskKey) === task) mediaSendTasks.delete(taskKey);
        throw e;
    }
    startMediaSendLoop(
        taskKey,
        task,
        () => s.sendMessage(fromJid, { sticker }),
        () => mediaSendDelays.get(`${fromJid}:sticker`) ?? DEFAULT_MEDIA_SEND_DELAY_MS,
        e => reply(fromJid, `❌ Couldn't send the saved sticker: ${e.message}`, m)
    );
}

// /-------------------------- IMAGE COMMAND CODE -----------------------------/
async function handleImageCommand(m, parts, fromJid, senderJid, isGroup) {
    if (!isGroup) {
        await reply(fromJid, '❌ Image save/send commands work only inside a group.', m);
        return;
    }

    const action = (parts[1] || '').toLowerCase();
    if (action === 'off') {
        if (parts.length !== 2) {
            await reply(fromJid, '❌ Use /image off with no extra arguments.', m);
            return;
        }
        const stopped = stopMediaSends(fromJid, 'image');
        await reply(fromJid, stopped
            ? '✅ Image sending stopped.'
            : 'ℹ️ No image send is currently running.', m);
        return;
    }

    if (action === 'delay') {
        if (parts.length === 2) {
            const delayMs = mediaSendDelays.get(`${fromJid}:image`) ?? DEFAULT_MEDIA_SEND_DELAY_MS;
            await reply(fromJid, `⏱️ Image repeat delay: *${delayMs} ms* (${msToSec(delayMs)}).`, m);
            return;
        }
        const delayArg = parts[2] || '';
        if (!/^\d+$/.test(delayArg) || parts.length !== 3) {
            await reply(fromJid, `❌ Use /image delay <milliseconds> (${MIN_MEDIA_SEND_DELAY_MS}-${MAX_MEDIA_SEND_DELAY_MS}).`, m);
            return;
        }
        const delayMs = Number(delayArg);
        if (delayMs < MIN_MEDIA_SEND_DELAY_MS || delayMs > MAX_MEDIA_SEND_DELAY_MS) {
            await reply(fromJid, `❌ Image delay must be ${MIN_MEDIA_SEND_DELAY_MS}-${MAX_MEDIA_SEND_DELAY_MS} ms.`, m);
            return;
        }
        mediaSendDelays.set(`${fromJid}:image`, delayMs);
        saveState();
        await reply(fromJid, `✅ Image repeat delay set to *${delayMs} ms* (${msToSec(delayMs)}).`, m);
        return;
    }

    if (action === 'cooldown') {
        const secondsArg = parts[2] || '';
        if (!/^\d+$/.test(secondsArg) || parts.length !== 3) {
            await reply(fromJid, `❌ Use /image cooldown <seconds> (${MIN_MEDIA_COOLDOWN_SECONDS}-${MAX_MEDIA_COOLDOWN_SECONDS}).`, m);
            return;
        }
        const seconds = Number(secondsArg);
        if (seconds < MIN_MEDIA_COOLDOWN_SECONDS || seconds > MAX_MEDIA_COOLDOWN_SECONDS) {
            await reply(fromJid, `❌ Cooldown must be ${MIN_MEDIA_COOLDOWN_SECONDS}-${MAX_MEDIA_COOLDOWN_SECONDS} seconds.`, m);
            return;
        }
        mediaCooldowns.set(fromJid, seconds);
        saveState();
        await reply(fromJid, `✅ Sticker/image cooldown set to *${seconds}s* for this group.`, m);
        return;
    }

    if (action === 'save' || action === 'savs') {
        const idArg = parts[2] || '';
        if (!/^[1-9]\d{0,2}$/.test(idArg)) {
            await reply(fromJid, '❌ Use /image save <1-999> while replying to an image.\nExample: /image save 1', m);
            return;
        }

        const commandMessage = m.message?.deviceSentMessage?.message || m.message || {};
        const quotedMessage = commandMessage.extendedTextMessage?.contextInfo?.quotedMessage;
        const imageMessage = quotedMessage?.imageMessage;
        if (!imageMessage) {
            await reply(fromJid, '❌ Reply to an image with /image save <id>.', m);
            return;
        }

        const id = String(Number(idArg));
        const groupImages = savedImages.get(fromJid) || new Set();
        if (!groupImages.has(id) && groupImages.size >= MAX_IMAGES_PER_GROUP) {
            await reply(fromJid, `❌ This group already has ${MAX_IMAGES_PER_GROUP} saved images.`, m);
            return;
        }

        try {
            const stream = await downloadContentFromMessage(imageMessage, 'image');
            const chunks = [];
            let totalBytes = 0;
            for await (const chunk of stream) {
                totalBytes += chunk.length;
                if (totalBytes > MAX_IMAGE_BYTES) {
                    throw new Error('Image is larger than 8 MB.');
                }
                chunks.push(chunk);
            }
            if (!totalBytes) throw new Error('Image download was empty.');

            const mimetype = ALLOWED_IMAGE_MIME_TYPES.has(imageMessage.mimetype)
                ? imageMessage.mimetype
                : 'image/jpeg';
            fs.mkdirSync(IMAGE_DIR, { recursive: true });
            fs.writeFileSync(getSavedImagePath(fromJid, id), Buffer.concat(chunks));
            groupImages.add(id);
            savedImages.set(fromJid, groupImages);
            const imageMimeTypes = savedImageMimeTypes.get(fromJid) || new Map();
            imageMimeTypes.set(id, mimetype);
            savedImageMimeTypes.set(fromJid, imageMimeTypes);
            saveState();
            await reply(fromJid, `✅ Image saved as *${id}* in this group.`, m);
        } catch (e) {
            await reply(fromJid, `❌ Couldn't save that image: ${e.message}`, m);
        }
        return;
    }

    const idArg = parts[1] || '';
    if (!/^[1-9]\d{0,2}$/.test(idArg) || parts.length !== 2) {
        await reply(fromJid, '❌ Use /image <id> to start sending, then /image off to stop.\nExample: /image 1', m);
        return;
    }

    const id = String(Number(idArg));
    const groupImages = savedImages.get(fromJid);
    const imagePath = getSavedImagePath(fromJid, id);
    if (!groupImages?.has(id) || !fs.existsSync(imagePath)) {
        await reply(fromJid, `❌ Image *${id}* isn't saved in this group. Reply to an image with /image save ${id} first.`, m);
        return;
    }

    const taskKey = `${fromJid}:image`;
    if (mediaSendTasks.has(taskKey)) {
        await reply(fromJid, '⏳ An image loop is already running in this group. Use /image off to stop it.', m);
        return;
    }

    const cooldownKey = `${fromJid}:${jidToNum(senderJid)}`;
    const now = Date.now();
    const cooldownMs = (mediaCooldowns.get(fromJid) ?? DEFAULT_MEDIA_COOLDOWN_SECONDS) * 1000;
    const elapsed = now - (mediaSendLastAt.get(cooldownKey) || 0);
    if (elapsed < cooldownMs) {
        const waitSeconds = Math.ceil((cooldownMs - elapsed) / 1000);
        await reply(fromJid, `⏳ Wait ${waitSeconds}s before sending another saved image/sticker.`, m);
        return;
    }
    mediaSendLastAt.set(cooldownKey, now);

    const s = getActiveSockets(1)[0];
    if (!s) return;
    let image;
    try {
        image = fs.readFileSync(imagePath);
    } catch (e) {
        await reply(fromJid, `❌ Couldn't send the saved image: ${e.message}`, m);
        return;
    }
    const mimetype = savedImageMimeTypes.get(fromJid)?.get(id) || 'image/jpeg';

    const task = { groupJid: fromJid, type: 'image', stopped: false, cancelDelay: null };
    mediaSendTasks.set(taskKey, task);
    try {
        await reply(fromJid, '▶️ Image loop started. Use /image off to stop it.', m);
    } catch (e) {
        if (mediaSendTasks.get(taskKey) === task) mediaSendTasks.delete(taskKey);
        throw e;
    }
    startMediaSendLoop(
        taskKey,
        task,
        () => s.sendMessage(fromJid, { image, mimetype }),
        () => mediaSendDelays.get(`${fromJid}:image`) ?? DEFAULT_MEDIA_SEND_DELAY_MS,
        e => reply(fromJid, `❌ Couldn't send the saved image: ${e.message}`, m)
    );
}

// ─── Antilink handler ────────────────────────────────────────────────────────

const LINK_REGEX = /https?:\/\/\S+|wa\.me\/\S*|chat\.whatsapp\.com\/\S+|www\.\S+\.\S+/i;

function handleAntilink(sock, botIndex, m, fromJid, senderJid, isGroup, body) {
    if (!isGroup) return;
    if (m.key.fromMe) return;
    if (!antilinkGroups.has(fromJid)) return;
    if (!LINK_REGEX.test(body)) return;

    console.log(`[Antilink] Bot${botIndex} | group=${fromJid} | sender=${senderJid} | body="${body.slice(0,80)}"`);

    const sNum = jidToNum(senderJid);
    const delKey = { remoteJid: fromJid, fromMe: false, id: m.key.id, participant: m.key.participant };

    sock.sendMessage(fromJid, { delete: delKey }).then(() => {
        console.log(`[Antilink] ✅ Bot${botIndex} ne delete kiya link from ${sNum}`);
    }).catch(e => {
        console.error(`[Antilink] ❌ Bot${botIndex} delete fail (bot admin hai?): ${e.message}`);
    });

    if (botIndex === 1) {
        sock.sendMessage(fromJid, {
            text: `⚠️ @${sNum} sending links in this group is *not allowed!* ❌\n_Message has been deleted._`,
            mentions: [senderJid]
        }).catch(() => {});
    }
}

// ─── Auto-delete handler — multi-target ──────────────────────────────────────

function handleAutoDelete(sock, m, fromJid, senderJid, isGroup) {
    if (!isGroup) return;
    if (m.key.fromMe) return;
    const targets = autoDeleteTargets.get(fromJid);
    if (!targets?.size) return;
    const sNum  = jidToNum(senderJid);
    if (!sNum) return;
    const clean = t => t.replace(/\D/g,'');
    const match = [...targets].some(t => clean(sNum) === clean(t));
    if (!match) return;
    const delKey = {
        remoteJid:   fromJid,
        fromMe:      false,
        id:          m.key.id,
        participant: m.key.participant,
    };
    sock.sendMessage(fromJid, { delete: delKey }).catch(()=>{});
}

// ─── Auto-reply handler — DM only, per-number ────────────────────────────────

function handleAutoReply(sock, botIndex, m, fromJid, senderJid, isGroup) {
    if (botIndex !== 1) return;
    if (isGroup) return;
    if (m.key.fromMe) return;
    const key = m.key || {};
    const candidates = [
        senderJid,
        fromJid,
        key.remoteJidAlt,
        key.participantAlt,
        key.senderPn,
        key.participantPn,
    ]
        .map(normalizePhoneNumber)
        .filter(num => num.length >= 8 && num.length <= 15);
    const msg = [...new Set(candidates)]
        .map(num => autoReplyTargets.get(num))
        .find(Boolean);
    if (!msg) return;
    sock.sendMessage(fromJid, { text: msg }, { quoted: m })
        .catch(e => console.error('[AutoReply] Send failed:', e.message));
}

// ─── Target reply handler — group, random casual reply ───────────────────────

function handleTargetReply(sock, botIndex, m, fromJid, senderJid, isGroup) {
    if (botIndex !== 1) return;
    if (!isGroup) return;
    if (m.key.fromMe) return;
    const set = targetedUsers.get(fromJid);
    if (!set?.size) return;
    const sNum = jidToNum(senderJid).replace(/\D/g,'');
    if (!sNum) return;
    if (!set.has(sNum)) return;
    const pick = TARGET_REPLIES[Math.floor(Math.random() * TARGET_REPLIES.length)];
    sock.sendMessage(fromJid, { text: pick }, { quoted: m }).catch(() => {});
}

// ─── Session bootstrap ────────────────────────────────────────────────────────

async function startSession(botIndex, version, phone = null) {
    const sessionDir = SESSION_DIR(botIndex);
    if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    const needsPairing = !state.creds.registered;
    let   pairingDone  = false;

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        auth:   state,
        printQRInTerminal:              false,
        browser:                        Browsers.macOS('Chrome'),
        syncFullHistory:                false,
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect:            true,
    });

    sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
        if (qr && needsPairing && phone && !pairingDone) {
            pairingDone = true;
            try {
                const code = await sock.requestPairingCode(phone.replace(/[^0-9]/g, ''));
                const fmt8 = code.match(/.{1,4}/g)?.join('-') || code;
                console.log(`\n╔══════════════════════════════════════╗`);
                console.log(`║  🔑 BOT ${botIndex} PAIRING CODE: ${fmt8.padEnd(9)} ║`);
                console.log(`╚══════════════════════════════════════╝`);
                console.log(`\n📲 WhatsApp → Linked Devices → Link a Device → Enter code\n`);
            } catch (e) {
                console.error(`[Bot ${botIndex}] Pairing code error:`, e.message);
                pairingDone = false;
            }
        }

        if (connection === 'open') {
            sockets.set(botIndex, sock);
            console.log(`✅ Bot ${botIndex}/${MAX_BOTS} connected! (${sockets.size} active)`);
            try {
                const uid = sock.user?.id;
                if (uid) {
                    const norm  = jidNormalizedUser(uid);
                    const phone = jidToNum(norm);
                    owners.add(norm); owners.add(phone);
                    if (botIndex===1) console.log(`👑 Owner: ${phone}`);
                }
                const lid = sock.authState?.creds?.me?.lid||sock.user?.lid;
                if (lid) {
                    const lidStr = String(lid).includes('@') ? String(lid) : `${lid}@lid`;
                    owners.add(lidStr); owners.add(jidToNum(lidStr));
                }
                saveState();
            } catch {}
            if (sockets.size === MAX_BOTS) {
                console.log(`\n⚔️  Sab ${MAX_BOTS}/${MAX_BOTS} bots active! RAJ X Mafia ready! 💀\n`);
            }
            scheduleTaskResume();
            if (botIndex === 1 && gcNameProtections.size) {
                (async () => {
                    for (const [groupJid, protectedSubject] of gcNameProtections) {
                        await enforceGcNameProtection(sock, groupJid, protectedSubject);
                    }
                })();
            }
        }

        if (connection === 'close') {
            sockets.delete(botIndex);
            const code = lastDisconnect?.error?.output?.statusCode;
            if (code === DisconnectReason.loggedOut) {
                console.log(`💀 Bot ${botIndex} logged out! Delete the sessions/bot${botIndex} folder and restart.`);
            } else {
                console.log(`⚔️  Bot ${botIndex} reconnecting... (code: ${code})`);
                setTimeout(()=>startSession(botIndex,version,null), 3000);
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('groups.update', async updates => {
        if (botIndex !== 1 || !Array.isArray(updates)) return;

        for (const update of updates) {
            const groupJid = update?.id || update?.jid;
            if (!groupJid?.endsWith('@g.us') || typeof update.subject !== 'string') continue;

            const protectedSubject = gcNameProtections.get(groupJid);
            if (!protectedSubject || update.subject === protectedSubject) continue;
            await enforceGcNameProtection(sock, groupJid, protectedSubject);
        }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type!=='notify' && type!=='append') return;

        for (const m of messages) {
            try {
                if (!m.message) continue;
                const fromMe  = !!m.key.fromMe;
                const fromJid = m.key.remoteJid;
                if (!fromJid) continue;
                const isGroup = fromJid.endsWith('@g.us');

                let senderJid;
                if (isGroup) {
                    senderJid = m.key.participant || jidNormalizedUser(sock.user?.id||'');
                } else {
                    senderJid = fromMe ? jidNormalizedUser(sock.user?.id||'') : fromJid;
                }
                if (!senderJid) continue;

                if (fromMe && isGroup && m.key.participant) {
                    const pNum = jidToNum(m.key.participant);
                    if (![...owners].some(o=>jidToNum(o)===pNum)) {
                        owners.add(m.key.participant); owners.add(pNum);
                    }
                }

                const msg = m.message?.deviceSentMessage?.message || m.message;
                const body =
                    msg?.conversation                               ||
                    msg?.extendedTextMessage?.text                  ||
                    msg?.imageMessage?.caption                      ||
                    msg?.videoMessage?.caption                      ||
                    msg?.buttonsResponseMessage?.selectedDisplayText ||
                    msg?.listResponseMessage?.title                 ||
                    '';

                handleAutoDelete(sock, m, fromJid, senderJid, isGroup);
                handleAntilink(sock, botIndex, m, fromJid, senderJid, isGroup, body);
                handleAutoReply(sock, botIndex, m, fromJid, senderJid, isGroup);
                handleTargetReply(sock, botIndex, m, fromJid, senderJid, isGroup);

                if (!fromMe && (autoReactEmoji || randomReactChats.has(fromJid))) {
                    if (randomReactChats.has(fromJid)) {
                        (async () => {
                            const pool = [...RANDOM_REACT_EMOJIS].sort(() => Math.random() - 0.5);
                            const picks = pool.slice(0, 15);
                            for (const e of picks) {
                                await sock.sendMessage(fromJid, { react: { text: e, key: m.key } }).catch(()=>{});
                                await new Promise(r => setTimeout(r, 2000));
                            }
                        })();
                    } else {
                        sock.sendMessage(fromJid,{react:{text:autoReactEmoji,key:m.key}}).catch(()=>{});
                    }
                }

                if (botIndex!==1) continue;

                const text = body.trim();

                _ol(`[DEBUG] bot1 | from=${fromJid} | sender=${senderJid} | body="${text.slice(0,80)}" | auth=${isAuthorized(senderJid)}`);

                if (!text.startsWith('/')) continue;
                if (!isAuthorized(senderJid)) continue;

                await handleCommand(m, text, fromJid, senderJid, isGroup);
            } catch(e) {
                if (!String(e.message||'').includes('rate-overlimit'))
                    console.error('[Error]', e.message);
            }
        }
    });
}

// ─── Main ─────────────────────────────────────────────────────────────────────

// Render Health-Check Server (Zaroori hai taaki Render deploy fail na kare)
const PORT = process.env.PORT || 3000;
http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(`${BOT_NAME} is running! Active bots: ${sockets.size}/${MAX_BOTS}\n`);
}).listen(PORT, '0.0.0.0', () => {
    console.log(`🌐 Health-check server listening on port ${PORT}`);
});

async function main() {
    const { version } = await fetchLatestBaileysVersion();

    console.log(`\n⚔️  ${BOT_NAME} — Pairing Code Login System\n`);

    // 1. Auto-load sessions that are already registered (creds.json exists)
    const loaded = new Set();
    for (let i = 1; i <= MAX_BOTS; i++) {
        const credsFile = `${SESSION_DIR(i)}/creds.json`;
        if (fs.existsSync(credsFile)) {
            console.log(`🔄 Loading Bot ${i} existing session...`);
            await startSession(i, version, null);
            loaded.add(i);
            if (loaded.size < MAX_BOTS) await sleep(1500);
        }
    }

    // 2. Ask phone numbers for remaining empty slots (if interactive or env var provided)
    const envPhones = (process.env.BOT_PHONES || '').split(',').map(p => p.replace(/[^0-9]/g, '')).filter(Boolean);
    let envIdx = 0;

    let nextSlot = 1;
    while (loaded.size < MAX_BOTS) {
        while (loaded.has(nextSlot) && nextSlot <= MAX_BOTS) nextSlot++;
        if (nextSlot > MAX_BOTS) break;

        let phone = '';
        if (envIdx < envPhones.length) {
            phone = envPhones[envIdx++];
            console.log(`\n📱 Using phone from BOT_PHONES env for Bot ${nextSlot}: ${phone}`);
        } else if (process.stdin.isTTY) {
            phone = (await ask(`\n📱 Bot ${nextSlot} phone number (e.g. 919876543210): `))
                .replace(/[^0-9]/g, '');
        } else {
            // Render background logs mein input type nahi kar sakte, isliye ruk jao
            break;
        }

        if (!phone || phone.length < 10) { console.log('❌ Invalid number! Try again.'); continue; }

        await startSession(nextSlot, version, phone);
        loaded.add(nextSlot);

        if (loaded.size < MAX_BOTS && process.stdin.isTTY && envIdx >= envPhones.length) {
            const more = await ask('❓ Add another bot? (y/n): ');
            if (more.trim().toLowerCase() !== 'y') break;
        }
    }

    if (loaded.size === 0) {
        console.log('⚠️ Koi existing session nahi mila! Render ke Environment Variables mein BOT_PHONES=919876543210 daalo ya sessions folder upload karo.');
    } else {
        console.log(`\n✅ ${loaded.size} session(s) started. ${BOT_NAME} is running!\n`);
    }
}

main().catch(console.error);
